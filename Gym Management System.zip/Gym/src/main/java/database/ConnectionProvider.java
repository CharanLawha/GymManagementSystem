
package database;
import java.sql.*;


import javax.swing.JOptionPane;

import java.lang.*;

 // Or your chosen package name (ensure it matches other files)

import java.sql.*;

/**
 * Provides a static method to get a connection to the 'gms' database.
 * Ensure you have the MySQL JDBC driver (MySQL Connector/J) added
 * to your project's libraries/classpath.
 */
public class ConnectionProvider {

    // --- Database Connection Details ---
    // URL format: jdbc:mysql://hostname:port/databaseName
    private static final String DB_URL = "jdbc:mysql://localhost:3306/gms";

    // --- !!! IMPORTANT: Replace with your actual MySQL username and password !!! ---
    private static final String DB_USER = "root"; // e.g., "root"
    private static final String DB_PASSWORD = "Lawha786"; // Your MySQL password

    /**
     * Establishes and returns a connection to the gms database.
     * Handles potential exceptions during connection.
     *
     * @return Connection object if successful, otherwise null.
     */
    public static Connection getCon() {
        Connection con = null; // Initialize connection object to null
        try {
            // Optional: Explicitly load the driver (needed for older JDBC versions)
            // Class.forName("com.mysql.cj.jdbc.Driver");

            // Attempt to establish the database connection
            con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Optional: Print success message for debugging
            // System.out.println("Database connection successful!");

        } catch (SQLException e) {
            // Handle SQL exceptions (e.g., wrong credentials, DB down)
            System.err.println("SQL Exception: Failed to connect to database.");
            System.err.println("Error Code: " + e.getErrorCode());
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Message: " + e.getMessage());
            // Show a user-friendly error message
            JOptionPane.showMessageDialog(null,
                "Database Connection Error:\n" + e.getMessage() + "\nPlease check database status and credentials.",
                "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace(); // Print stack trace for detailed debugging
            return null; // Return null to indicate connection failure

        }
        // catch (ClassNotFoundException e) {
            // Handle case where JDBC driver is not found
        //     System.err.println("ClassNotFoundException: MySQL JDBC Driver not found.");
        //     System.err.println("Message: " + e.getMessage());
        //     JOptionPane.showMessageDialog(null,
        //         "Driver Error: MySQL JDBC Driver not found.\nEnsure the Connector/J JAR is in your classpath.",
        //         "Driver Error", JOptionPane.ERROR_MESSAGE);
        //     e.printStackTrace();
        //     return null; // Return null to indicate failure
        // }
        catch (Exception e) {
             // Catch any other unexpected exceptions during connection
             System.err.println("Unexpected Exception during database connection:");
             e.printStackTrace();
             JOptionPane.showMessageDialog(null,
                "An unexpected error occurred during database connection:\n" + e.getMessage(),
                "Connection Error", JOptionPane.ERROR_MESSAGE);
             return null;
        }

        return con; // Return the established connection object
    }

    /**
     * Main method for testing the database connection independently.
     * Run this method to verify your credentials and driver setup.
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        System.out.println("Testing database connection...");
        Connection testCon = getCon(); // Attempt to get a connection

        if (testCon != null) {
            System.out.println("Connection Test SUCCESSFUL!");
            try {
                // It's crucial to close the connection after testing
                testCon.close();
                System.out.println("Test connection closed.");
            } catch (SQLException e) {
                System.err.println("Failed to close the test connection: " + e.getMessage());
            }
        } else {
            System.err.println("Connection Test FAILED. Check console output for errors.");
        }
    }
}


/*
public class ConnectionProvider {
    public static Connection getConnection(){
        String url = "jdbc:mysql://localhost:3306/gms";
        String username = "root";
        String password = "Lawha786";
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connnection = DriverManager.getConnection(url,username,password);
            return connnection;
        }catch(Exception e){
            return null;
        }
    }

    
}
*/