package com.mycompany.gymmanagementsystem;

// Or your chosen package name

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter; // For sorting

import database.ConnectionProvider;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector; // Vector is commonly used with DefaultTableModel

/**
 * Frame to display the list of all members from the database.
 * Includes search functionality.
 */
public class memberList extends JFrame implements ActionListener, KeyListener {

    // --- UI Components ---
    private JLabel titleLabel, searchLabel;
    private JTextField searchField;
    private JButton closeButton, refreshButton; // Added refresh button
    private JTable memberTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    private TableRowSorter<DefaultTableModel> sorter; // For sorting/filtering

    /**
     * Constructor: Sets up the member list frame.
     */
    public memberList() {
        // --- Frame Setup ---
        setTitle("List of Members");
        setSize(1000, 600); // Wider frame
        setLocationRelativeTo(null); // Center
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this window
        setUndecorated(true); // Optional
        setLayout(null);
        getContentPane().setBackground(new Color(240, 240, 255)); // Light lavender background

        // --- Title and Close Button ---
        titleLabel = new JLabel("MEMBER LIST");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(102, 0, 153)); // Purple color
        titleLabel.setBounds(400, 15, 300, 35);
        add(titleLabel);

        closeButton = new JButton("X");
        closeButton.setFont(new Font("Arial", Font.BOLD, 16));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(Color.RED);
        closeButton.setBounds(940, 10, 50, 30);
        closeButton.addActionListener(this);
        add(closeButton);

        // --- Search Functionality ---
        searchLabel = new JLabel("Search:");
        searchLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        searchLabel.setBounds(30, 70, 70, 25);
        add(searchLabel);

        searchField = new JTextField();
        searchField.setFont(new Font("Tahoma", Font.PLAIN, 14));
        searchField.setBounds(100, 70, 300, 25);
        searchField.addKeyListener(this); // Add key listener for live search
        add(searchField);

        refreshButton = new JButton("Refresh");
        refreshButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        refreshButton.setBounds(420, 70, 100, 25);
        refreshButton.addActionListener(this);
        add(refreshButton);


        // --- Member Table ---
        // Define column names
        String[] columnNames = {"ID", "First Name", "Last Name", "Gender", "Phone", "Email", "Address", "Amount", "Type", "Reg Date", "Trainer ID", "Pay Date"};

        // Create table model (non-editable by default)
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table cells non-editable
            }
        };

        memberTable = new JTable(tableModel);
        memberTable.setFont(new Font("Tahoma", Font.PLAIN, 12));
        memberTable.setRowHeight(25);
        memberTable.getTableHeader().setFont(new Font("Tahoma", Font.BOLD, 13));
        memberTable.getTableHeader().setBackground(new Color(153, 153, 255)); // Header color
        memberTable.getTableHeader().setForeground(Color.WHITE);
        memberTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Allow only one row selection

        // --- Enable Sorting ---
        sorter = new TableRowSorter<>(tableModel);
        memberTable.setRowSorter(sorter);

        // --- Scroll Pane ---
        scrollPane = new JScrollPane(memberTable);
        scrollPane.setBounds(30, 110, 940, 450); // Position below search/title
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        memberTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); // Allow horizontal scrolling if needed
        // Adjust column widths (example)
        setColumnWidths();


        add(scrollPane);

        // --- Load Initial Data ---
        loadMemberData();

        // Make frame visible
        setVisible(true);
    }

     /**
     * Sets preferred column widths for the table.
     */
    private void setColumnWidths() {
        // Adjust these widths as needed based on typical data length
        memberTable.getColumnModel().getColumn(0).setPreferredWidth(50);   // ID
        memberTable.getColumnModel().getColumn(1).setPreferredWidth(120);  // First Name
        memberTable.getColumnModel().getColumn(2).setPreferredWidth(120);  // Last Name
        memberTable.getColumnModel().getColumn(3).setPreferredWidth(70);   // Gender
        memberTable.getColumnModel().getColumn(4).setPreferredWidth(110);  // Phone
        memberTable.getColumnModel().getColumn(5).setPreferredWidth(180);  // Email
        memberTable.getColumnModel().getColumn(6).setPreferredWidth(250);  // Address
        memberTable.getColumnModel().getColumn(7).setPreferredWidth(80);   // Amount
        memberTable.getColumnModel().getColumn(8).setPreferredWidth(80);   // Type
        memberTable.getColumnModel().getColumn(9).setPreferredWidth(100);  // Reg Date
        memberTable.getColumnModel().getColumn(10).setPreferredWidth(80);  // Trainer ID
        memberTable.getColumnModel().getColumn(11).setPreferredWidth(100); // Pay Date
    }


    /**
     * Loads member data from the database into the table model.
     */
    private void loadMemberData() {
        // Clear existing data
        tableModel.setRowCount(0);

        String query = "SELECT ID, firstName, lastName, gender, phoneNum, email, address, amountPay, memberType, dateRegister, trainerID, payDate FROM member ORDER BY ID";
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;

        try {
            con = ConnectionProvider.getCon();
             if (con == null) {
                 JOptionPane.showMessageDialog(this, "Database connection failed.", "Error", JOptionPane.ERROR_MESSAGE);
                 return;
            }
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("ID"));
                row.add(rs.getString("firstName"));
                row.add(rs.getString("lastName"));
                row.add(rs.getString("gender"));
                row.add(rs.getString("phoneNum"));
                row.add(rs.getString("email"));
                row.add(rs.getString("address"));
                // Handle potential null amount
                Object amount = rs.getObject("amountPay");
                row.add(amount != null ? amount : ""); // Display empty string if null

                row.add(rs.getString("memberType"));
                row.add(rs.getDate("dateRegister")); // Display as Date object default format

                // Handle potential null trainer ID
                Object trainerIdObj = rs.getObject("trainerID");
                row.add(trainerIdObj != null ? trainerIdObj : "N/A"); // Display N/A if null

                row.add(rs.getDate("payDate")); // Display as Date object default format

                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading member data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            // Close resources
             try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
             try { if (st != null) st.close(); } catch (SQLException e) { e.printStackTrace(); }
             try { if (con != null) con.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    /**
     * Filters the table based on the text in the search field.
     */
    private void filterTable() {
        String searchText = searchField.getText().trim();
        if (searchText.length() == 0) {
            sorter.setRowFilter(null); // No filter, show all rows
        } else {
            // Case-insensitive search across all columns
            // (?i) makes the regex case-insensitive
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
        }
    }

    /**
     * Handles button clicks.
     * @param e The ActionEvent object.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == closeButton) {
            setVisible(false);
            dispose();
        } else if (e.getSource() == refreshButton) {
             loadMemberData(); // Reload data from DB
             searchField.setText(""); // Clear search field
             sorter.setRowFilter(null); // Clear filter
        }
    }

    // --- KeyListener Methods for Live Search ---

    @Override
    public void keyTyped(KeyEvent e) {
        // Not used
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // Not used
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Filter table whenever a key is released in the search field
        if (e.getSource() == searchField) {
            filterTable();
        }
    }

    /**
     * Main method (for testing purposes).
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new memberList());
    }
}