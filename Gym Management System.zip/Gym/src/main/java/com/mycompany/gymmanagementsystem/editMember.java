package com.mycompany.gymmanagementsystem;

/*auther charan */

import javax.swing.*;

import database.ConnectionProvider;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date; // Use java.util.Date for current date

/**
 * Frame for editing or deleting an existing member in the Gym Management System.
 * Requires searching for the member first.
 */
public class editMember extends JFrame implements ActionListener {

    // --- UI Components ---
    private JLabel titleLabel, searchIdLabel;
    private JTextField searchIdField;
    private JButton searchButton, updateButton, deleteButton, resetButton, closeButton;

    // Member details fields (similar to newMember)
    private JLabel firstNameLabel, lastNameLabel, genderLabel, phoneLabel, emailLabel, addressLabel;
    private JLabel amountLabel, typeLabel, regDateLabel, trainerLabel, payDateLabel;
    private JTextField firstNameField, lastNameField, phoneField, emailField, addressField, amountField;
    private JComboBox<String> genderCombo, typeCombo, trainerCombo;
    private JTextField regDateField, payDateField; // Display only for regDate

    private int currentMemberId = -1; // To store the ID of the member being edited

    /**
     * Constructor: Sets up the edit/delete member frame.
     */
    public editMember() {
        // --- Frame Setup ---
        setTitle("Update / Delete Member");
        setSize(850, 700); // Slightly taller for search bar
        setLocationRelativeTo(null); // Center
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this window
        setUndecorated(true); // Optional
        setLayout(null);
        getContentPane().setBackground(new Color(255, 245, 230)); // Light orange background

        // --- Title and Close Button ---
        titleLabel = new JLabel("UPDATE / DELETE MEMBER");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(204, 85, 0)); // Orange color
        titleLabel.setBounds(220, 20, 500, 35);
        add(titleLabel);

        closeButton = new JButton("X");
        closeButton.setFont(new Font("Arial", Font.BOLD, 16));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(Color.RED);
        closeButton.setBounds(790, 10, 50, 30);
        closeButton.addActionListener(this);
        add(closeButton);

        // --- Search Section ---
        searchIdLabel = new JLabel("Enter Member ID:");
        searchIdLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        searchIdLabel.setBounds(50, 80, 140, 25);
        add(searchIdLabel);

        searchIdField = new JTextField();
        searchIdField.setFont(new Font("Tahoma", Font.PLAIN, 14));
        searchIdField.setBounds(200, 80, 100, 25);
        add(searchIdField);

        searchButton = new JButton("Search");
        searchButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        searchButton.setBounds(320, 80, 100, 25);
        searchButton.addActionListener(this);
        add(searchButton);

        JSeparator separator = new JSeparator();
        separator.setBounds(30, 120, 790, 10);
        add(separator);


        // --- Member Details Fields (Initially Disabled) ---
        int labelX = 50;
        int fieldX = 180;
        int labelWidth = 120;
        int fieldWidth = 250;
        int yPos = 140; // Start below separator
        int yGap = 40;
        Font labelFont = new Font("Tahoma", Font.BOLD, 14);
        Font fieldFont = new Font("Tahoma", Font.PLAIN, 14);

        firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setFont(labelFont);
        firstNameLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(firstNameLabel);
        firstNameField = new JTextField();
        firstNameField.setFont(fieldFont);
        firstNameField.setBounds(fieldX, yPos, fieldWidth, 25);
        add(firstNameField);
        yPos += yGap;

        lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setFont(labelFont);
        lastNameLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(lastNameLabel);
        lastNameField = new JTextField();
        lastNameField.setFont(fieldFont);
        lastNameField.setBounds(fieldX, yPos, fieldWidth, 25);
        add(lastNameField);
        yPos += yGap;

        genderLabel = new JLabel("Gender:");
        genderLabel.setFont(labelFont);
        genderLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(genderLabel);
        genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderCombo.setFont(fieldFont);
        genderCombo.setBounds(fieldX, yPos, fieldWidth, 25);
        genderCombo.setBackground(Color.WHITE);
        add(genderCombo);
        yPos += yGap;

        phoneLabel = new JLabel("Phone Number:");
        phoneLabel.setFont(labelFont);
        phoneLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(phoneLabel);
        phoneField = new JTextField();
        phoneField.setFont(fieldFont);
        phoneField.setBounds(fieldX, yPos, fieldWidth, 25);
        add(phoneField);
        yPos += yGap;

        emailLabel = new JLabel("Email:");
        emailLabel.setFont(labelFont);
        emailLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(emailLabel);
        emailField = new JTextField();
        emailField.setFont(fieldFont);
        emailField.setBounds(fieldX, yPos, fieldWidth, 25);
        add(emailField);
        yPos += yGap;

        addressLabel = new JLabel("Address:");
        addressLabel.setFont(labelFont);
        addressLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(addressLabel);
        addressField = new JTextField();
        addressField.setFont(fieldFont);
        addressField.setBounds(fieldX, yPos, fieldWidth + 200, 25); // Wider address
        add(addressField);
        yPos += yGap;

        // --- Right Side Fields ---
        labelX = 480; // Adjusted X for right column
        fieldX = 600;
        fieldWidth = 200; // Adjusted width
        yPos = 140; // Reset Y for the second column

        amountLabel = new JLabel("Amount (Pay):");
        amountLabel.setFont(labelFont);
        amountLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(amountLabel);
        amountField = new JTextField();
        amountField.setFont(fieldFont);
        amountField.setBounds(fieldX, yPos, fieldWidth, 25);
        add(amountField);
        yPos += yGap;

        typeLabel = new JLabel("Member Type:");
        typeLabel.setFont(labelFont);
        typeLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(typeLabel);
        typeCombo = new JComboBox<>(new String[]{"Basic", "Plus", "Premium"});
        typeCombo.setFont(fieldFont);
        typeCombo.setBounds(fieldX, yPos, fieldWidth, 25);
        typeCombo.setBackground(Color.WHITE);
        add(typeCombo);
        yPos += yGap;

        regDateLabel = new JLabel("Register Date:");
        regDateLabel.setFont(labelFont);
        regDateLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(regDateLabel);
        regDateField = new JTextField();
        regDateField.setFont(fieldFont);
        regDateField.setBounds(fieldX, yPos, fieldWidth, 25);
        regDateField.setEditable(false); // Registration date cannot be changed
        add(regDateField);
        yPos += yGap;

        trainerLabel = new JLabel("Assign Trainer:");
        trainerLabel.setFont(labelFont);
        trainerLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(trainerLabel);
        trainerCombo = new JComboBox<>();
        trainerCombo.setFont(fieldFont);
        trainerCombo.setBounds(fieldX, yPos, fieldWidth, 25);
        trainerCombo.setBackground(Color.WHITE);
        loadTrainers(); // Load trainers
        add(trainerCombo);
        yPos += yGap;

        payDateLabel = new JLabel("Last Pay Date:");
        payDateLabel.setFont(labelFont);
        payDateLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(payDateLabel);
        payDateField = new JTextField(); // Allow editing payment date
        payDateField.setFont(fieldFont);
        payDateField.setBounds(fieldX, yPos, fieldWidth, 25);
        payDateField.setToolTipText("Enter YYYY-MM-DD");
        add(payDateField);
        yPos += yGap;


        // --- Action Buttons ---
        int buttonY = 620; // Position buttons at the bottom
        updateButton = new JButton("Update");
        updateButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        updateButton.setBackground(new Color(0, 102, 204)); // Blue
        updateButton.setForeground(Color.WHITE);
        updateButton.setBounds(150, buttonY, 100, 35);
        updateButton.addActionListener(this);
        add(updateButton);

        deleteButton = new JButton("Delete");
        deleteButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        deleteButton.setBackground(new Color(204, 0, 0)); // Red
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setBounds(300, buttonY, 100, 35);
        deleteButton.addActionListener(this);
        add(deleteButton);

        resetButton = new JButton("Reset");
        resetButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        resetButton.setBackground(new Color(255, 153, 0)); // Orange
        resetButton.setForeground(Color.WHITE);
        resetButton.setBounds(450, buttonY, 100, 35);
        resetButton.addActionListener(this);
        add(resetButton);

        // Initially disable editing fields and action buttons
        setFieldsEditable(false);

        // Make frame visible
        setVisible(true);
    }

    /**
     * Enables or disables all member detail input fields and action buttons.
     * @param editable True to enable, false to disable.
     */
    private void setFieldsEditable(boolean editable) {
        firstNameField.setEditable(editable);
        lastNameField.setEditable(editable);
        genderCombo.setEnabled(editable);
        phoneField.setEditable(editable);
        emailField.setEditable(editable);
        addressField.setEditable(editable);
        amountField.setEditable(editable);
        typeCombo.setEnabled(editable);
        trainerCombo.setEnabled(editable);
        payDateField.setEditable(editable);
        // regDateField is never editable

        updateButton.setEnabled(editable);
        deleteButton.setEnabled(editable);
        resetButton.setEnabled(editable); // Reset button should work after search
    }

    /**
     * Loads trainer names and IDs into the trainer combo box.
     * Same as in newMember.
     */
    private void loadTrainers() {
        trainerCombo.removeAllItems(); // Clear existing items before loading
        trainerCombo.addItem("None"); // Option for no trainer
        String query = "SELECT ID, name FROM trainer ORDER BY name";
        try (Connection con = ConnectionProvider.getCon();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(query)) {

            while (rs.next()) {
                trainerCombo.addItem(rs.getInt("ID") + ": " + rs.getString("name"));
            }
        } catch (SQLException e) {
            System.err.println("Error loading trainers: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Could not load trainer list.", "Database Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            System.err.println("Unexpected error loading trainers: " + e.getMessage());
        }
    }

    /**
     * Handles button clicks.
     * @param e The ActionEvent object.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == searchButton) {
            searchMember();
        } else if (e.getSource() == updateButton) {
            updateMember();
        } else if (e.getSource() == deleteButton) {
            deleteMember();
        } else if (e.getSource() == resetButton) {
        	clearForm();
            // Reset only the editable fields if a member is loaded, or clear search
            if (currentMemberId != -1) {
                searchMember(); // Reload original data for the current member
            } else {
                clearForm(); // Clear search and fields if no member loaded
            }
        } else if (e.getSource() == closeButton) {
            setVisible(false);
            dispose();
        }
    }

    /**
     * Clears all fields, including the search field, and disables editing.
     */
    private void clearForm() {
        searchIdField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        genderCombo.setSelectedIndex(0);
        phoneField.setText("");
        emailField.setText("");
        addressField.setText("");
        amountField.setText("");
        typeCombo.setSelectedIndex(0);
        regDateField.setText("");
        trainerCombo.setSelectedIndex(0);
        payDateField.setText("");
        currentMemberId = -1;
        setFieldsEditable(false);
    }


    /**
     * Searches for a member by ID and populates the fields.
     */
    private void searchMember() {
        String memberIdStr = searchIdField.getText().trim();
        if (memberIdStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Member ID to search.", "Input Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            currentMemberId = Integer.parseInt(memberIdStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Member ID. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            clearForm(); // Clear fields if ID is invalid
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean memberFound = false;

        String query = "SELECT * FROM member WHERE ID = ?";

        try {
            con = ConnectionProvider.getCon();
             if (con == null) {
                 JOptionPane.showMessageDialog(this, "Database connection failed.", "Error", JOptionPane.ERROR_MESSAGE);
                 return;
            }
            ps = con.prepareStatement(query);
            ps.setInt(1, currentMemberId);
            rs = ps.executeQuery();

            if (rs.next()) {
                memberFound = true;
                // Populate fields
                firstNameField.setText(rs.getString("firstName"));
                lastNameField.setText(rs.getString("lastName"));
                genderCombo.setSelectedItem(rs.getString("gender"));
                phoneField.setText(rs.getString("phoneNum"));
                emailField.setText(rs.getString("email"));
                addressField.setText(rs.getString("address"));

                // Handle null amount
                double amount = rs.getDouble("amountPay");
                if (rs.wasNull()) {
                    amountField.setText("");
                } else {
                    amountField.setText(String.format("%.2f", amount)); // Format to 2 decimal places
                }

                typeCombo.setSelectedItem(rs.getString("memberType"));
                regDateField.setText(rs.getDate("dateRegister").toString()); // Display date

                // Handle null payment date
                Date payDate = rs.getDate("payDate");
                 if (payDate != null) {
                    payDateField.setText(new SimpleDateFormat("yyyy-MM-dd").format(payDate));
                } else {
                    payDateField.setText("");
                }


                // Handle trainer selection
                int trainerId = rs.getInt("trainerID");
                if (rs.wasNull()) {
                    trainerCombo.setSelectedItem("None");
                } else {
                    boolean foundTrainer = false;
                    for (int i = 0; i < trainerCombo.getItemCount(); i++) {
                        String item = trainerCombo.getItemAt(i);
                        if (!item.equals("None") && item.startsWith(trainerId + ":")) {
                            trainerCombo.setSelectedIndex(i);
                            foundTrainer = true;
                            break;
                        }
                    }
                     if (!foundTrainer) {
                        trainerCombo.setSelectedItem("None"); // Default if trainer ID not in list
                        System.err.println("Warning: Trainer ID " + trainerId + " not found in ComboBox.");
                    }
                }

                setFieldsEditable(true); // Enable fields for editing

            } else {
                JOptionPane.showMessageDialog(this, "Member ID not found.", "Search Result", JOptionPane.INFORMATION_MESSAGE);
                clearForm(); // Clear fields if not found
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error during search: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            clearForm();
        } finally {
             try { if (rs != null) rs.close(); } catch (SQLException e) { e.printStackTrace(); }
             try { if (ps != null) ps.close(); } catch (SQLException e) { e.printStackTrace(); }
             try { if (con != null) con.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    /**
     * Updates the current member's data in the database.
     */
    private void updateMember() {
        if (currentMemberId == -1) {
            JOptionPane.showMessageDialog(this, "Please search for a member first.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // --- Data Validation (Similar to newMember, add more as needed) ---
         if (firstNameField.getText().trim().isEmpty() || lastNameField.getText().trim().isEmpty() ||
            phoneField.getText().trim().isEmpty() || emailField.getText().trim().isEmpty() ||
            addressField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Required fields cannot be empty.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double amount = 0.0;
        if (!amountField.getText().trim().isEmpty()) {
            try {
                amount = Double.parseDouble(amountField.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid amount format.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        // --- Get Data from Fields ---
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String gender = (String) genderCombo.getSelectedItem();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();
        String address = addressField.getText().trim();
        String memberType = (String) typeCombo.getSelectedItem();
        String payDateStr = payDateField.getText().trim();


        // --- Handle Trainer Selection ---
        Integer trainerId = null;
        String selectedTrainer = (String) trainerCombo.getSelectedItem();
        if (selectedTrainer != null && !selectedTrainer.equals("None")) {
            try {
                trainerId = Integer.parseInt(selectedTrainer.split(":")[0]);
            } catch (Exception ex) { /* Handle error */ }
        }

        // --- Handle Payment Date ---
         java.sql.Date payDateSql = null;
         try {
            if (!payDateStr.isEmpty()) {
                 if (!payDateStr.matches("\\d{4}-\\d{2}-\\d{2}")) {
                     JOptionPane.showMessageDialog(this, "Invalid Payment Date format. Use YYYY-MM-DD.", "Input Error", JOptionPane.WARNING_MESSAGE);
                     return;
                 }
                payDateSql = java.sql.Date.valueOf(payDateStr);
            }
         } catch (IllegalArgumentException ex) {
             JOptionPane.showMessageDialog(this, "Invalid Payment Date value.", "Input Error", JOptionPane.WARNING_MESSAGE);
             return;
         }


        // --- Database Update ---
        Connection con = null;
        PreparedStatement ps = null;

        // Note: Consider updating the payment table as well if payDate or amount changes significantly.
        // This example only updates the member table. A more robust solution would update both transactionally.
        String query = "UPDATE member SET firstName=?, lastName=?, gender=?, phoneNum=?, email=?, address=?, amountPay=?, memberType=?, trainerID=?, payDate=? WHERE ID=?";

        try {
            con = ConnectionProvider.getCon();
             if (con == null) {
                 JOptionPane.showMessageDialog(this, "Database connection failed.", "Error", JOptionPane.ERROR_MESSAGE);
                 return;
            }

            ps = con.prepareStatement(query);
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, gender);
            ps.setString(4, phone);
            ps.setString(5, email);
            ps.setString(6, address);
             if (amountField.getText().trim().isEmpty()) {
                 ps.setNull(7, Types.DECIMAL);
            } else {
                 ps.setDouble(7, amount);
            }
            ps.setString(8, memberType);
            if (trainerId == null) {
                ps.setNull(9, Types.INTEGER);
            } else {
                ps.setInt(9, trainerId);
            }
             if (payDateSql == null) {
                 ps.setNull(10, Types.DATE);
            } else {
                 ps.setDate(10, payDateSql);
            }
            ps.setInt(11, currentMemberId); // WHERE clause

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Member details updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                // Optionally clear form or keep data displayed
                 // clearForm(); // Or just disable fields again
                 setFieldsEditable(false); // Disable after successful update
                 searchIdField.setText(""); // Clear search field
                 currentMemberId = -1;

            } else {
                JOptionPane.showMessageDialog(this, "Failed to update member. Member ID might not exist anymore.", "Update Failed", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error during update: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
             try { if (ps != null) ps.close(); } catch (SQLException e) { e.printStackTrace(); }
             try { if (con != null) con.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    /**
     * Deletes the current member from the database after confirmation.
     * Handles deletion from both payment and member tables.
     */
    private void deleteMember() {
        if (currentMemberId == -1) {
            JOptionPane.showMessageDialog(this, "Please search for a member first.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete member " + currentMemberId + " (" + firstNameField.getText() + " " + lastNameField.getText() + ")?\nThis action cannot be undone.",
            "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (choice == JOptionPane.YES_OPTION) {
            Connection con = null;
            PreparedStatement psPayment = null;
            PreparedStatement psMember = null;

            String deletePaymentQuery = "DELETE FROM payment WHERE memberID = ?";
            String deleteMemberQuery = "DELETE FROM member WHERE ID = ?";

            try {
                con = ConnectionProvider.getCon();
                 if (con == null) {
                     JOptionPane.showMessageDialog(this, "Database connection failed.", "Error", JOptionPane.ERROR_MESSAGE);
                     return;
                }
                con.setAutoCommit(false); // Start transaction

                // 1. Delete from payment table (foreign key constraint)
                psPayment = con.prepareStatement(deletePaymentQuery);
                psPayment.setInt(1, currentMemberId);
                psPayment.executeUpdate(); // Execute even if no payment record exists

                // 2. Delete from member table
                psMember = con.prepareStatement(deleteMemberQuery);
                psMember.setInt(1, currentMemberId);
                int rowsAffected = psMember.executeUpdate();

                if (rowsAffected > 0) {
                    con.commit(); // Commit transaction
                    JOptionPane.showMessageDialog(this, "Member deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    clearForm(); // Clear the form after deletion
                } else {
                    con.rollback(); // Rollback if member deletion failed
                    JOptionPane.showMessageDialog(this, "Failed to delete member. Member might have already been deleted.", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
                }

            } catch (SQLException e) {
                 try { if (con != null) con.rollback(); } catch (SQLException ex) { System.err.println("Rollback failed: " + ex.getMessage());}
                JOptionPane.showMessageDialog(this, "Database error during deletion: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            } finally {
                 try { if (psPayment != null) psPayment.close(); } catch (SQLException e) { e.printStackTrace(); }
                 try { if (psMember != null) psMember.close(); } catch (SQLException e) { e.printStackTrace(); }
                 try { if (con != null) { con.setAutoCommit(true); con.close(); } } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }


    /**
     * Main method (for testing purposes).
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new editMember());
    }
}