package com.mycompany.gymmanagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Timer;
import java.util.TimerTask;

public class SplashScreen extends JFrame {

    private JLabel imageLabel;
    private String[] imagePaths = {
        "C:/Users/Charan Lawha/Desktop/Gym/src/main/java/images/background.jpg",
   
        "C:/Users/Charan Lawha/Desktop/Gym/src/main/java/images/quote1.jpg"
    };
    private int currentIndex = 0;
    private Timer timer;
    private boolean splashEnded = false;

    public SplashScreen() {
        setUndecorated(true);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new BorderLayout());

        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(imageLabel, BorderLayout.CENTER);

        // Show first image and start animation
        showImage(currentIndex);
        playAnimation();

        // Any key press will end splash
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                endSplash();
            }
        });

        setFocusable(true);
        setVisible(true);
    }

    private void showImage(int index) {
        ImageIcon icon = new ImageIcon(imagePaths[index]);

        int width = imageLabel.getWidth();
        int height = imageLabel.getHeight();

        if (width == 0 || height == 0) {
            // Fallback to screen size
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            width = screenSize.width;
            height = screenSize.height;
        }

        Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(img));
    }

    private void playAnimation() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                if (currentIndex >= imagePaths.length - 1) {
                    timer.cancel();
                    endSplash(); // Auto end after last image
                } else {
                    currentIndex++;
                    showImage(currentIndex);
                }
            }
        }, 1000, 3000); // 3 seconds per image
    }

    private void endSplash() {
    	
        if (!splashEnded) {
            splashEnded = true;
            if (timer != null) timer.cancel();
            dispose(); // Close splash screen
            new home(); // Open home screen
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SplashScreen());
    }
}
