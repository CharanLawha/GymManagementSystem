package com.mycompany.gymmanagementsystem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

public class login extends JFrame implements ActionListener {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JLabel errorLabel;
    private JCheckBox showPasswordCheckbox;
    private JButton loginButton, closeButton;
    private JPanel loginCard;

    public login() {
        // Frame setup
        setTitle("Gym Management Login");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setUndecorated(true);
        setOpacity(0f);
        fadeIn();

        // Background gradient
        JPanel bg = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(0,153,204),
                                                     0, getHeight(), new Color(0,102,153));
                g2.setPaint(gp);
                g2.fillRect(0,0,getWidth(),getHeight());
            }
        };
        bg.setLayout(null);

        // Card panel
        loginCard = new JPanel();
        loginCard.setBounds(75, 70, 350, 260);
        loginCard.setBackground(Color.WHITE);
        loginCard.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        loginCard.setLayout(null);
        loginCard.setOpaque(true);
        loginCard.setLocation(75, -300);       // start off-screen
        bg.add(loginCard);
        slideInCard();

        // Title
        JLabel title = new JLabel("GYM LOGIN", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setBounds(0, 10, 350, 30);
        loginCard.add(title);

        // Username
        JLabel uLabel = new JLabel("Username:");
        uLabel.setBounds(30, 60, 80, 25);
        loginCard.add(uLabel);
        usernameField = new JTextField();
        usernameField.setBounds(120, 60, 180, 25);
        loginCard.add(usernameField);

        // Password
        JLabel pLabel = new JLabel("Password:");
        pLabel.setBounds(30, 100, 80, 25);
        loginCard.add(pLabel);
        passwordField = new JPasswordField();
        passwordField.setBounds(120, 100, 180, 25);
        loginCard.add(passwordField);

        // Show password
        showPasswordCheckbox = new JCheckBox("Show Password");
        showPasswordCheckbox.setBounds(120, 130, 150, 20);
        showPasswordCheckbox.setBackground(Color.WHITE);
        showPasswordCheckbox.addActionListener(this);
        loginCard.add(showPasswordCheckbox);

        // Error label
        errorLabel = new JLabel("Invalid credentials!", SwingConstants.CENTER);
        errorLabel.setForeground(Color.RED);
        errorLabel.setBounds(50, 155, 250, 25);
        errorLabel.setVisible(false);
        loginCard.add(errorLabel);

        // Login button
        loginButton = createAnimatedButton("Login", 50, 190, 100, 30, new Color(0,153,51));
        loginButton.addActionListener(e -> {
            shakeOnError();
            actionPerformed(e);
        });
        loginCard.add(loginButton);

        // Close button
        closeButton = createAnimatedButton("Close", 180, 190, 100, 30, new Color(204,0,0));
        closeButton.addActionListener(this);
        loginCard.add(closeButton);

        setContentPane(bg);
        setVisible(true);
    }

    /** Fade-in window on launch **/
    private void fadeIn() {
        Timer t = new Timer(20, null);
        t.addActionListener(new ActionListener() {
            float op = 0;
            @Override
            public void actionPerformed(ActionEvent e) {
                op += 0.05f;
                if (op >= 1f) {
                    op = 1f;
                    t.stop();
                }
                setOpacity(op);
            }
        });
        t.start();
    }

    /** Slide the login card down into view **/
    private void slideInCard() {
        Timer t = new Timer(5, null);
        t.addActionListener(new ActionListener() {
            int y = -300;
            @Override
            public void actionPerformed(ActionEvent e) {
                y += 5;
                if (y >= 70) {
                    y = 70;
                    ((Timer)e.getSource()).stop();
                }
                loginCard.setLocation(75, y);
            }
        });
        t.start();
    }

    /** Shake the card panel when login fails **/
    private void shakeOnError() {
        if (!errorLabel.isVisible()) return;
        Timer t = new Timer(20, null);
        t.addActionListener(new ActionListener() {
            int count = 0;
            @Override
            public void actionPerformed(ActionEvent e) {
                int offset = (count % 2 == 0) ? 10 : -10;
                loginCard.setLocation(75 + offset, loginCard.getY());
                if (++count > 6) {
                    loginCard.setLocation(75, loginCard.getY());
                    ((Timer)e.getSource()).stop();
                }
            }
        });
        t.start();
    }

    /** Creates a button with hover animation **/
    private JButton createAnimatedButton(String text, int x, int y, int w, int h, Color base) {
        JButton btn = new JButton(text);
        btn.setBounds(x, y, w, h);
        btn.setBackground(base);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(new EmptyBorder(5, 5, 5, 5));
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(base.brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(base);
            }
        });
        return btn;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        if (src == loginButton) {
            String u = usernameField.getText();
            String p = new String(passwordField.getPassword());
            if (u.equals("admin") && p.equals("admin")) {
                setVisible(false);
                new SplashScreen().setVisible(true);
            } else {
                errorLabel.setVisible(true);
            }
        }
        else if (src == closeButton) {
            if (JOptionPane.showConfirmDialog(this, "Exit application?", "Confirm",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        }
        else if (src == showPasswordCheckbox) {
            passwordField.setEchoChar(showPasswordCheckbox.isSelected() ? (char)0 : '•');
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(login::new);
    }
}
