/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gymmanagementsystem;

import database.ConnectionProvider;

import java.awt.Color;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * A simple panel or frame displaying membership benefits information.
 * This version is a standalone JFrame. It could also be a JPanel added to another window.
 */
public class benefitsPanel extends JFrame implements ActionListener {

    // --- UI Components ---
    private JLabel titleLabel;
    private JTextArea benefitsTextArea;
    private JButton closeButton;
    private JScrollPane scrollPane;

    /**
     * Constructor: Sets up the benefits display frame.
     */
    public benefitsPanel() {
        // --- Frame Setup ---
        setTitle("Membership Benefits");
        setSize(500, 400);
        setLocationRelativeTo(null); // Center relative to parent or screen
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this window
        // setUndecorated(true); // Optional: Can keep decorations for this info window
        setLayout(null); // Using absolute positioning
        getContentPane().setBackground(new Color(245, 245, 220)); // Beige background

        // --- Title ---
        titleLabel = new JLabel("GMS Membership Tiers");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(50, 50, 50)); // Dark Gray
        titleLabel.setBounds(120, 20, 300, 30);
        add(titleLabel);

        // --- Benefits Text Area (Read-only) ---
        benefitsTextArea = new JTextArea();
        benefitsTextArea.setFont(new Font("Tahoma", Font.PLAIN, 14));
        benefitsTextArea.setEditable(false); // Make it read-only
        benefitsTextArea.setLineWrap(true); // Wrap text to fit width
        benefitsTextArea.setWrapStyleWord(true); // Wrap at word boundaries
        benefitsTextArea.setBackground(getContentPane().getBackground()); // Match background
        benefitsTextArea.setMargin(new Insets(10, 10, 10, 10)); // Add padding

        // --- Populate Benefits Text ---
        String benefitsText =
        	    "*** Membership Benefits ***\n\n" +
        	    "**Basic :**\n" +
        	    "* Access to gym floor during standard hours.\n" +
        	    "* Use of cardio and weight equipment.\n" +
        	    "* Locker room access.\n\n" +
        	    "**Plus :**\n" +
        	    "* All Basic benefits.\n" +
        	    "* Access to group fitness classes (e.g., Yoga, Zumba).\n" +
        	    "* Extended gym access hours.\n" +
        	    "* Option to assign a personal trainer (additional fees may apply).\n\n" +
        	    "**Premium :**\n" +
        	    "* All Plus benefits.\n" +
        	    "* Access to specialized training areas (if available).\n" +
        	    "* Towel service.\n" +
        	    "* Discounts on supplements and merchandise.\n" +
        	    "* Priority booking for classes and trainers.\n\n" +
        	    "------------------------------------\n" ;

        benefitsTextArea.setText(benefitsText);
        benefitsTextArea.setCaretPosition(0); // Scroll to top

        // --- Scroll Pane for Text Area ---
        scrollPane = new JScrollPane(benefitsTextArea);
        scrollPane.setBounds(30, 60, 440, 250); // Position and size
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        add(scrollPane);


        // --- Close Button ---
        closeButton = new JButton("Close");
        closeButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        closeButton.setBounds(200, 325, 100, 30);
        closeButton.addActionListener(this);
        add(closeButton);

        // Make frame visible
        setVisible(true);
    }

    /**
     * Handles button clicks.
     * @param e The ActionEvent object.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == closeButton) {
            setVisible(false); // Hide the window
            dispose(); // Release resources
        }
    }

    /**
     * Main method (for testing purposes).
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new benefitsPanel());
    }
}