package com.mycompany.gymmanagementsystem;

import database.ConnectionProvider;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

/**
 * Frame to view payment statuses and potentially record new payments.
 */
public class payment extends JFrame implements ActionListener, KeyListener {

    // --- UI Components ---
    private JLabel titleLabel, searchLabel, memberIdLabel, paymentDateLabel, amountLabel;
    private JTextField searchField, memberIdField, amountField;
    private JFormattedTextField paymentDateField; // Use JFormattedTextField for date input
    private JButton closeButton, refreshButton, savePaymentButton;
    private JTable paymentTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    private TableRowSorter<DefaultTableModel> sorter;

    private String memberIdForPayment; // To receive member ID from newMember
    private double amountDue;         // To receive amount due from newMember

    /**
     * Constructor for when called from newMember with member ID and amount.
     */
    public payment(String memberId, double amount) {
        this.memberIdForPayment = memberId;
        this.amountDue = amount;
        initComponents();
        populatePaymentDetails();
        loadAllMemberPaymentData(); // Load all member payment data initially
    }

    /**
     * Default constructor (for standalone use or other scenarios).
     */
    public payment() {
        initComponents();
        loadAllMemberPaymentData();
    }

    private void initComponents() {
        // --- Frame Setup ---
        setTitle("Payment Information");
        setSize(1100, 650); // Wider frame
        setLocationRelativeTo(null); // Center
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setUndecorated(true); // Optional
        setLayout(null);
        getContentPane().setBackground(new Color(255, 255, 230)); // Light yellow background

        // --- Title and Close Button ---
        titleLabel = new JLabel("PAYMENT STATUS & RECORDING");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(180, 150, 0)); // Gold-ish color
        titleLabel.setBounds(280, 15, 600, 35);
        add(titleLabel);

        closeButton = new JButton("X");
        closeButton.setFont(new Font("Arial", Font.BOLD, 16));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(Color.RED);
        closeButton.setBounds(1040, 10, 50, 30);
        closeButton.addActionListener(this);
        add(closeButton);

        // --- Search Functionality (for table) ---
        searchLabel = new JLabel("Search Table:");
        searchLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        searchLabel.setBounds(30, 70, 110, 25);
        add(searchLabel);

        searchField = new JTextField();
        searchField.setFont(new Font("Tahoma", Font.PLAIN, 14));
        searchField.setBounds(140, 70, 300, 25);
        searchField.addKeyListener(this); // Add key listener for live table search
        add(searchField);

        refreshButton = new JButton("Refresh Table");
        refreshButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        refreshButton.setBounds(460, 70, 150, 25);
        refreshButton.addActionListener(this);
        add(refreshButton);

        // --- Payment Recording Section ---
        JSeparator separator = new JSeparator();
        separator.setBounds(30, 110, 1040, 10);
        add(separator);

        JLabel recordTitle = new JLabel("Record New Payment:");
        recordTitle.setFont(new Font("Tahoma", Font.BOLD, 16));
        recordTitle.setBounds(30, 125, 200, 30);
        add(recordTitle);

        memberIdLabel = new JLabel("Member ID:");
        memberIdLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        memberIdLabel.setBounds(50, 165, 80, 25);
        add(memberIdLabel);

        memberIdField = new JTextField();
        memberIdField.setFont(new Font("Tahoma", Font.PLAIN, 14));
        memberIdField.setBounds(140, 165, 100, 25);
        add(memberIdField);

        paymentDateLabel = new JLabel("Payment Date:");
        paymentDateLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        paymentDateLabel.setBounds(260, 165, 100, 25);
        add(paymentDateLabel);

        // Use JFormattedTextField for easier date input
        try {
            paymentDateField = new JFormattedTextField(new SimpleDateFormat("yyyy-MM-dd"));
            paymentDateField.setFont(new Font("Tahoma", Font.PLAIN, 14));
            paymentDateField.setBounds(370, 165, 120, 25);
            paymentDateField.setValue(new Date()); // Default to today's date
            paymentDateField.setToolTipText("YYYY-MM-DD");
        } catch (Exception e) {
            // Fallback or handle error if SimpleDateFormat fails
            paymentDateField = new JFormattedTextField(); // Basic fallback
            paymentDateField.setBounds(370, 165, 120, 25);
            System.err.println("Could not create date formatter: " + e.getMessage());
        }
        add(paymentDateField);


        amountLabel = new JLabel("Amount Paid:");
        amountLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        amountLabel.setBounds(510, 165, 100, 25);
        add(amountLabel);

        amountField = new JTextField();
        amountField.setFont(new Font("Tahoma", Font.PLAIN, 14));
        amountField.setBounds(620, 165, 100, 25);
        amountField.setToolTipText("e.g., 19.99");
        add(amountField);

        savePaymentButton = new JButton("Save Payment");
        savePaymentButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        savePaymentButton.setBackground(new Color(0, 153, 51)); // Green
        savePaymentButton.setForeground(Color.WHITE);
        savePaymentButton.setBounds(750, 165, 150, 25);
        savePaymentButton.addActionListener(this);
        add(savePaymentButton);

        JSeparator separator2 = new JSeparator();
        separator2.setBounds(30, 205, 1040, 10);
        add(separator2);


        // --- Payment Status Table ---
        String[] columnNames = {"Payment ID", "Member ID", "Member Name", "Payment Date", "Due Date", "Days Remaining", "Status"};

        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Non-editable
            }
        };

        paymentTable = new JTable(tableModel);
        paymentTable.setFont(new Font("Tahoma", Font.PLAIN, 12));
        paymentTable.setRowHeight(25);
        paymentTable.getTableHeader().setFont(new Font("Tahoma", Font.BOLD, 13));
        paymentTable.getTableHeader().setBackground(new Color(255, 204, 102)); // Header color
        paymentTable.getTableHeader().setForeground(Color.DARK_GRAY);
        paymentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        sorter = new TableRowSorter<>(tableModel);
        paymentTable.setRowSorter(sorter);

        scrollPane = new JScrollPane(paymentTable);
        scrollPane.setBounds(30, 225, 1040, 380); // Position below recording section
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        paymentTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        setColumnWidths();

        add(scrollPane);
    }

    private void populatePaymentDetails() {
        if (memberIdForPayment != null) {
            memberIdField.setText(memberIdForPayment);
            memberIdField.setEditable(false); // Prevent editing when pre-filled
        }
        if (amountDue != 0.0) {
            amountField.setText(String.valueOf(amountDue));
            amountField.setEditable(false);   // Prevent editing when pre-filled
        }
    }


    /**
     * Sets preferred column widths for the payment table.
     */
    private void setColumnWidths() {
        paymentTable.getColumnModel().getColumn(0).setPreferredWidth(80);   // Payment ID
        paymentTable.getColumnModel().getColumn(1).setPreferredWidth(80);   // Member ID
        paymentTable.getColumnModel().getColumn(2).setPreferredWidth(180);  // Member Name
        paymentTable.getColumnModel().getColumn(3).setPreferredWidth(120);  // Payment Date
        paymentTable.getColumnModel().getColumn(4).setPreferredWidth(120);  // Due Date
        paymentTable.getColumnModel().getColumn(5).setPreferredWidth(120);  // Days Remaining
        paymentTable.getColumnModel().getColumn(6).setPreferredWidth(100);  // Status
    }


    /**
     * Loads all member data with their latest payment status into the table model.
     */
    private void loadAllMemberPaymentData() {
        tableModel.setRowCount(0); // Clear existing data

        String query = "SELECT m.ID, CONCAT(m.firstName, ' ', m.lastName) AS memberName, " +
                "MAX(p.paymentDate) AS latestPaymentDate, " +
                "p.dueDate, p.dayRemaining, p.status, MAX(p.paymentID) AS latestPaymentID " +
                "FROM member m LEFT JOIN payment p ON m.ID = p.memberID " +
                "GROUP BY m.ID, memberName, p.dueDate, p.dayRemaining, p.status " +
                "ORDER BY m.ID";

        Connection con = null;
        Statement st = null;
        ResultSet rs = null;

        try {
            con = ConnectionProvider.getCon();
            if (con == null) {
                JOptionPane.showMessageDialog(this, "Database connection failed.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("latestPaymentID")); // Latest Payment ID
                row.add(rs.getInt("ID"));
                row.add(rs.getString("memberName"));
                row.add(rs.getDate("latestPaymentDate")); // Latest Payment Date
                row.add(rs.getDate("dueDate"));
                row.add(rs.getString("dayRemaining"));
                row.add(rs.getString("status"));
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading member payment data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (st != null) st.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Filters the payment table based on the text in the search field.
     */
    private void filterTable() {
        String searchText = searchField.getText().trim();
        if (searchText.length() == 0) {
            sorter.setRowFilter(null);
        } else {
            // Case-insensitive search
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
        }
    }

    /**
     * Handles button clicks.
     *
     * @param e The ActionEvent object.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == closeButton) {
            setVisible(false);
            dispose();
        } else if (e.getSource() == refreshButton) {
            loadAllMemberPaymentData(); // Reload data
            searchField.setText(""); // Clear search
            sorter.setRowFilter(null); // Clear filter
            // Clear input fields for new payment
            memberIdField.setText("");
            amountField.setText("");
            paymentDateField.setValue(new Date());
            memberIdField.setEditable(true);
            amountField.setEditable(true);
        } else if (e.getSource() == savePaymentButton) {
            recordPayment();
        }
    }

    /**
     * Records a new payment for a member.
     */
    private void recordPayment() {
        // --- Validation ---
        String memberIdStr = memberIdField.getText().trim();
        String amountStr = amountField.getText().trim();
        Date paymentDateUtil = (Date) paymentDateField.getValue(); // Get date from formatted field

        if (memberIdStr.isEmpty() || amountStr.isEmpty() || paymentDateUtil == null) {
            JOptionPane.showMessageDialog(this, "Please enter Member ID, Payment Date, and Amount.", "Input Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int memberId;
        double amountPaid;
        java.sql.Date paymentDateSql;

        try {
            memberId = Integer.parseInt(memberIdStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Member ID. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            amountPaid = Double.parseDouble(amountStr);
            if (amountPaid <= 0) {
                JOptionPane.showMessageDialog(this, "Amount paid must be positive.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Amount format. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        paymentDateSql = new java.sql.Date(paymentDateUtil.getTime());

        // --- Database Interaction ---
        Connection con = null;
        PreparedStatement psCheckMember = null;
        PreparedStatement psCheckPaymentStatus = null;
        PreparedStatement psInsertPayment = null;
        PreparedStatement psUpdateMember = null; // To update member's last pay date
        ResultSet rsCheckMember = null;
        ResultSet rsCheckPaymentStatus = null;

        try {
            con = ConnectionProvider.getCon();
            if (con == null) {
                JOptionPane.showMessageDialog(this, "Database connection failed.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            con.setAutoCommit(false); // Start transaction

            // 1. Check if Member ID exists
            String checkMemberQuery = "SELECT ID FROM member WHERE ID = ?";
            psCheckMember = con.prepareStatement(checkMemberQuery);
            psCheckMember.setInt(1, memberId);
            rsCheckMember = psCheckMember.executeQuery();
            if (!rsCheckMember.next()) {
                JOptionPane.showMessageDialog(this, "Member ID " + memberId + " does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
                con.rollback();
                return;
            }
            rsCheckMember.close();
            psCheckMember.close();

            // 2. Check the current payment status of the member
            String checkPaymentStatusQuery = "SELECT status FROM payment WHERE memberID = ? ORDER BY paymentDate DESC LIMIT 1";
            psCheckPaymentStatus = con.prepareStatement(checkPaymentStatusQuery);
            psCheckPaymentStatus.setInt(1, memberId);
            rsCheckPaymentStatus = psCheckPaymentStatus.executeQuery();

            if (rsCheckPaymentStatus.next() && "Paid".equalsIgnoreCase(rsCheckPaymentStatus.getString("status"))) {
                JOptionPane.showMessageDialog(this, "Payment already recorded for Member ID: " + memberId + " (Status: Paid).", "Information", JOptionPane.INFORMATION_MESSAGE);
                con.rollback();
                return;
            }
            rsCheckPaymentStatus.close();
            psCheckPaymentStatus.close();

            // 3. Calculate Due Date and Days Remaining
            Calendar cal =Calendar.getInstance();
            cal.setTime(paymentDateSql);
            cal.add(Calendar.MONTH, 1); // Assume 1 month validity
            java.sql.Date dueDateSql = new java.sql.Date(cal.getTimeInMillis());

            long timeDiff = dueDateSql.getTime() - paymentDateSql.getTime();
            long daysRemaining = timeDiff / (1000 * 60 * 60 * 24);
            String daysRemainingStr = daysRemaining + " Days";

            // 4. Insert new payment record
            String insertPaymentQuery = "INSERT INTO payment (memberID, paymentDate, dueDate, dayRemaining, status) VALUES (?, ?, ?, ?, ?)";
            psInsertPayment = con.prepareStatement(insertPaymentQuery);
            psInsertPayment.setInt(1, memberId);
            psInsertPayment.setDate(2, paymentDateSql);
            psInsertPayment.setDate(3, dueDateSql);
            psInsertPayment.setString(4, daysRemainingStr);
            psInsertPayment.setString(5, "Paid");

            int rowsAffected = psInsertPayment.executeUpdate();

            // 5. Update the member table's last pay date and potentially amount (optional but good practice)
            String updateMemberQuery = "UPDATE member SET payDate = ?, amountPay = ? WHERE ID = ?";
            psUpdateMember = con.prepareStatement(updateMemberQuery);
            psUpdateMember.setDate(1, paymentDateSql);
            psUpdateMember.setDouble(2, amountPaid); // Update the amount in member table too
            psUpdateMember.setInt(3, memberId);
            psUpdateMember.executeUpdate();


            if (rowsAffected > 0) {
                con.commit(); // Commit transaction
                JOptionPane.showMessageDialog(this, "Payment recorded successfully for Member ID: " + memberId, "Success", JOptionPane.INFORMATION_MESSAGE);
                loadAllMemberPaymentData(); // Refresh the table to show updated payment status
                // Clear input fields
                memberIdField.setText("");
                amountField.setText("");
                paymentDateField.setValue(new Date()); // Reset date to today
            } else {
                con.rollback(); // Rollback if insert failed
                JOptionPane.showMessageDialog(this, "Failed to record payment.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            try {
                if (con != null) con.rollback();
            } catch (SQLException ex) {
                System.err.println("Rollback failed: " + ex.getMessage());
            }
            JOptionPane.showMessageDialog(this, "Database error recording payment: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            // Close all resources
            try {
                if (rsCheckMember != null) rsCheckMember.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (psCheckMember != null) psCheckMember.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (rsCheckPaymentStatus != null) rsCheckPaymentStatus.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (psCheckPaymentStatus != null) psCheckPaymentStatus.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (psInsertPayment != null) psInsertPayment.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (psUpdateMember != null) psUpdateMember.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                if (con != null) {
                    con.setAutoCommit(true);
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


    // --- KeyListener Methods for Live Table Search ---
    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getSource() == searchField) {
            filterTable();
        }
    }

    /**
     * Main method (for testing purposes).
     *
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new payment());
    }
}