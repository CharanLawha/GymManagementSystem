
package com.mycompany.gymmanagementsystem;

import java.awt.Color;
/*auther charan */
import javax.swing.JOptionPane;


 // Or your chosen package name

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Main home screen/dashboard for the Gym Management System.
 * Appears after successful login. Provides navigation to other modules.
 */
public class home extends JFrame implements ActionListener {

    // --- Menu Bar and Items ---
    private JMenuBar menuBar;
    private JMenu newMemberMenu, updateDeleteMenu, listMemberMenu, paymentMenu, trainerMenu, benefitsMenu, logoutMenu, exitMenu;

    /**
     * Constructor: Sets up the home frame with a menu bar.
     */
    public home() {
        // --- Frame Setup ---
    	setTitle("GMS Home - Welcome Admin");
    	setExtendedState(JFrame.MAXIMIZED_BOTH);
    	setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    	setLayout(null); 
    	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    	ImageIcon backgroundIcon = new ImageIcon("C:\\Users\\Charan Lawha\\Desktop\\Gym\\src\\main\\java\\images\\bg.jpg");
    	Image backgroundImg = backgroundIcon.getImage();
    	Image scaledImg = backgroundImg.getScaledInstance(screenSize.width, screenSize.height, Image.SCALE_SMOOTH);
    	JLabel backgroundLabel = new JLabel(new ImageIcon(scaledImg));
    	backgroundLabel.setBounds(0, 0, screenSize.width, screenSize.height);
    	backgroundLabel.setBounds(0, 0, 1920, 1080); // Full screen background
    	setContentPane(backgroundLabel); // Set the background
    	backgroundLabel.setLayout(null);
        // --- Menu Bar ---
    	setLayout(null);
    	setContentPane(backgroundLabel);
    	backgroundLabel.setLayout(null);
        menuBar = new JMenuBar();
        menuBar.setBackground(new Color(51, 153, 255)); // Nice blue for menu bar

        // --- Menu Items ---
        Font menuFont = new Font("Arial", Font.BOLD, 14);
        Color menuColor = Color.WHITE;

        newMemberMenu = createMenu("New Member", "icons/new_member.png", menuFont, menuColor); // Add icons later
        updateDeleteMenu = createMenu("Update & Delete Member", "icons/update_delete.png", menuFont, menuColor);
        listMemberMenu = createMenu("List of Members", "icons/list_members.png", menuFont, menuColor);
        paymentMenu = createMenu("Payment", "icons/payment.png", menuFont, menuColor);
        trainerMenu = createMenu("Trainers", "icons/trainer.png", menuFont, menuColor);
        benefitsMenu = createMenu("Membership Benefits", "icons/benefits.png", menuFont, menuColor);
        logoutMenu = createMenu("Logout", "icons/logout.png", menuFont, menuColor);
        exitMenu = createMenu("Exit", "icons/exit.png", menuFont, menuColor);

        // --- Add Menus to Bar ---
        menuBar.add(newMemberMenu);
        menuBar.add(updateDeleteMenu);
        menuBar.add(listMemberMenu);
        menuBar.add(paymentMenu);
        menuBar.add(trainerMenu);
        menuBar.add(benefitsMenu);
        menuBar.add(logoutMenu);
        menuBar.add(exitMenu);

        setJMenuBar(menuBar);

        // --- Add Listeners ---
        addMenuListeners();

        // --- Add a Welcome Panel (Optional) ---
        JPanel welcomePanel = new JPanel();
        welcomePanel.setBounds(150, 60, 1000, 100); // Position and size
        welcomePanel.setOpaque(false); // Make it transparent
        JLabel welcomeLabel = new JLabel("Welcome to Gym Management System");
        welcomeLabel.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 40));
        welcomeLabel.setForeground(Color.black); // Set text to white
        welcomePanel.add(welcomeLabel);
        backgroundLabel.add(welcomePanel);
        // --- Window Closing Listener ---
         addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                handleExit();
            }
        });


        // Make frame visible
        setVisible(true);
    }

    /**
     * Helper method to create a JMenu with potential icon.
     */
    private JMenu createMenu(String title, String iconPath, Font font, Color color) {
        JMenu menu = new JMenu(title);
        menu.setFont(font);
        menu.setForeground(color);
        menu.setOpaque(true); // Needed for background color on some L&Fs
        menu.setBackground(menuBar.getBackground());
        // TODO: Add icon loading logic if icons are available
        // try {
        //     ImageIcon icon = new ImageIcon(getClass().getResource(iconPath));
        //     // Scale icon if necessary
        //     // Image img = icon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
        //     // menu.setIcon(new ImageIcon(img));
        //     menu.setIcon(icon);
        // } catch (Exception e) {
        //     System.err.println("Icon not found: " + iconPath);
        // }
        return menu;
    }


    /**
     * Adds MouseListeners to the menus to handle clicks.
     */
    private void addMenuListeners() {
        MouseAdapter menuListener = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JMenu clickedMenu = (JMenu) e.getSource();
                handleMenuAction(clickedMenu);
            }
        };

        newMemberMenu.addMouseListener(menuListener);
        updateDeleteMenu.addMouseListener(menuListener);
        listMemberMenu.addMouseListener(menuListener);
        paymentMenu.addMouseListener(menuListener);
        trainerMenu.addMouseListener(menuListener);
        benefitsMenu.addMouseListener(menuListener);
        logoutMenu.addMouseListener(menuListener);
        exitMenu.addMouseListener(menuListener);
    }

    /**
     * Handles actions when a menu is clicked.
     * @param menu The JMenu that was clicked.
     */
    private void handleMenuAction(JMenu menu) {
        if (menu == newMemberMenu) {
            // Open New Member Window
            new newMember().setVisible(true);
        } else if (menu == updateDeleteMenu) {
            // Open Edit/Delete Member Window (often combined with List)
            // For now, let's assume it's part of memberList or a separate search window
             new editMember().setVisible(true); // Example: Opens edit window directly
           //  System.out.println("Update/Delete Member Clicked - Open relevant window");
        } else if (menu == listMemberMenu) {
            // Open List Members Window
             new memberList().setVisible(true);
        } else if (menu == paymentMenu) {
            // Open Payment Window
             new payment().setVisible(true);
        } else if (menu == trainerMenu) {
            // Open Trainer Window
             new trainer().setVisible(true);
        } else if (menu == benefitsMenu) {
            // Open Benefits Window/Panel
             new benefitsPanel().setVisible(true); // Assuming it's a separate frame for now
        } else if (menu == logoutMenu) {
            // Handle Logout
            int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                setVisible(false); // Hide home window
                new login().setVisible(true); // Show login window
            }
        } else if (menu == exitMenu) {
            // Handle Exit
            handleExit();
        }
    }

     /**
     * Handles the application exit confirmation.
     */
    private void handleExit() {
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to exit the application?", "Confirm Exit", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            System.exit(0); // Exit the application
        }
    }


    /**
     * Dummy implementation for ActionListener (not strictly needed if using MouseListener for menus).
     * @param e The ActionEvent object.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // This might be used if you add buttons directly to the frame later
    }

    /**
     * Main method (optional, usually launched from login).
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new home());
    }
}