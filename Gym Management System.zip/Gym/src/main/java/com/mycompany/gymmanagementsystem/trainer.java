package com.mycompany.gymmanagementsystem;

import database.ConnectionProvider;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.Date; // Use java.util.Date for JFormattedTextField

/**
 * Frame to manage Trainers (View list, Add, Update) with enhanced UI,
 * animations, and corrected layout.
 * Last Updated: May 10, 2025
 */
public class trainer extends JFrame implements ActionListener, MouseListener {

    // --- UI Components ---
    private JLabel titleLabel;
    private JButton closeButton, refreshButton, saveButton, resetButton, updateButton;
    private JTable trainerTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    private TableRowSorter<DefaultTableModel> sorter;

    // --- Add/Update Trainer Fields ---
    private JLabel addTrainerTitleLabel, nameLabel, ageLabel, addressLabel, mobileLabel, joinDateLabel, idLabel;
    private JTextField nameField, ageField, addressField, mobileField, idField;
    private JFormattedTextField joinDateField;

    private int selectedTrainerId = -1; // To track the ID of the trainer being updated

    // --- For Animations ---
    private Timer windowFadeInTimer;
    private float currentWindowOpacity = 0f;
    private Timer componentsSlideInTimer;
    private List<Component> animatedComponentsList;
    private List<Rectangle> targetBoundsList;
    private int animationProgressCounter = 0;
    private static final int ANIMATION_X_OFFSET_SLIDE = -150; // Initial X offset for slide-in components
    private static final int ANIMATION_STAGGER_DELAY_STEPS = 2; // Controls delay (in timer ticks) between component animations

    // --- Styling Constants ---
    private static final Color COLOR_PRIMARY = new Color(0, 120, 215); // Professional Blue
    private static final Color COLOR_ACCENT_ERROR = new Color(220, 53, 69); // Red for close/errors
    private static final Color COLOR_BUTTON_GREEN = new Color(40, 167, 69);
    private static final Color COLOR_BUTTON_ORANGE = new Color(255, 127, 80);
    private static final Color COLOR_BUTTON_BLUE = new Color(0, 102, 204); // For Update button

    private static final Font FONT_GLOBAL_REGULAR = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_LABEL_BOLD = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_FIELD_INPUT = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_PAGE_TITLE = new Font("Segoe UI Semibold", Font.BOLD, 28);
    private static final Font FONT_SECTION_TITLE = new Font("Segoe UI", Font.BOLD, 18);

    private static final Color COLOR_BACKGROUND_MAIN = new Color(240, 245, 250); // Light grayish blue
    private static final Color COLOR_TEXT_FIELD_BORDER = COLOR_PRIMARY.darker();


    public trainer() {
        // Apply Nimbus Look and Feel for a modern appearance
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            System.err.println("Nimbus L&F not found or failed to load. Using default.");
        }

        // --- Frame Setup ---
        setTitle("Manage Trainers");
        setSize(950, 720); // Adjusted size for better spacing
        setLocationRelativeTo(null); // Center the window
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Dispose on close to free resources
        setUndecorated(true); // Custom look
        setLayout(null); // Using absolute positioning as per original structure
        getContentPane().setBackground(COLOR_BACKGROUND_MAIN);
        // Add a subtle border to the undecorated frame
        getRootPane().setBorder(BorderFactory.createLineBorder(COLOR_PRIMARY.darker(), 1));

        animatedComponentsList = new ArrayList<>();
        targetBoundsList = new ArrayList<>();

        initializeUIComponents();
        addUIListeners();
        loadTrainerDataFromDB();

        prepareComponentsForAnimation(); // Set initial states for animation
        startWindowFadeInAnimation();     // Start window fade-in

        setVisible(true); // Make frame visible AFTER setting opacity to 0 for fade-in
                          // Components slide-in will be triggered after fade-in completes
    }

    private void initializeUIComponents() {
        // --- Title and Close Button ---
        titleLabel = new JLabel("TRAINER MANAGEMENT");
        titleLabel.setFont(FONT_PAGE_TITLE);
        titleLabel.setForeground(COLOR_PRIMARY.darker());
        Rectangle titleBounds = new Rectangle(30, 20, 450, 35);
        titleLabel.setBounds(titleBounds);
        add(titleLabel);
        storeComponentForAnimation(titleLabel, titleBounds);

        closeButton = createStyledButton("X", COLOR_ACCENT_ERROR, COLOR_ACCENT_ERROR.brighter(), COLOR_ACCENT_ERROR.darker());
        closeButton.setBounds(getWidth() - 60, 15, 50, 30); // Position based on frame width
        add(closeButton);
        // Close button is typically not part of the main content slide-in animation

        // --- Add/Update Trainer Section ---
        addTrainerTitleLabel = new JLabel("Add / Update Trainer Details:");
        addTrainerTitleLabel.setFont(FONT_SECTION_TITLE);
        addTrainerTitleLabel.setForeground(COLOR_PRIMARY);
        Rectangle addTrainerTitleBounds = new Rectangle(30, 75, 350, 30);
        addTrainerTitleLabel.setBounds(addTrainerTitleBounds);
        add(addTrainerTitleLabel);
        storeComponentForAnimation(addTrainerTitleLabel, addTrainerTitleBounds);

        // Layout variables
        int labelX = 50;
        int fieldStartX = 180; // Increased for more space between label and field
        int yPos = 125;
        int yGap = 45;         // Increased vertical gap between rows
        int fieldHeight = 30;  // Standard height for text fields
        int nameFieldWidth = 240;
        int shortFieldWidth = 90; // For ID, Age
        int pairedElementGap = 30; // Horizontal gap between a field and its paired element (e.g., Name Field and Age Label)

        // --- Row 1: Trainer ID ---
        idLabel = new JLabel("Trainer ID:");
        idLabel.setFont(FONT_LABEL_BOLD);
        Rectangle idLabelBounds = new Rectangle(labelX, yPos, 120, fieldHeight);
        idLabel.setBounds(idLabelBounds);
        add(idLabel);
        storeComponentForAnimation(idLabel, idLabelBounds);

        idField = createStyledTextField();
        idField.setEditable(false); // ID is usually auto-generated or non-editable for updates
        Rectangle idFieldBounds = new Rectangle(fieldStartX, yPos, shortFieldWidth, fieldHeight);
        idField.setBounds(idFieldBounds);
        add(idField);
        storeComponentForAnimation(idField, idFieldBounds);
        yPos += yGap;

        // --- Row 2: Name and Age (on the same line) ---
        nameLabel = new JLabel("Full Name:");
        nameLabel.setFont(FONT_LABEL_BOLD);
        Rectangle nameLabelBounds = new Rectangle(labelX, yPos, 120, fieldHeight);
        nameLabel.setBounds(nameLabelBounds);
        add(nameLabel);
        storeComponentForAnimation(nameLabel, nameLabelBounds);

        nameField = createStyledTextField();
        Rectangle nameFieldBounds = new Rectangle(fieldStartX, yPos, nameFieldWidth, fieldHeight);
        nameField.setBounds(nameFieldBounds);
        add(nameField);
        storeComponentForAnimation(nameField, nameFieldBounds);

        int ageLabelX = fieldStartX + nameFieldWidth + pairedElementGap;
        ageLabel = new JLabel("Age:");
        ageLabel.setFont(FONT_LABEL_BOLD);
        Rectangle ageLabelBounds = new Rectangle(ageLabelX, yPos, 50, fieldHeight);
        ageLabel.setBounds(ageLabelBounds);
        add(ageLabel);
        storeComponentForAnimation(ageLabel, ageLabelBounds);

        ageField = createStyledTextField();
        Rectangle ageFieldBounds = new Rectangle(ageLabelX + ageLabel.getWidth() + 10, yPos, shortFieldWidth, fieldHeight);
        ageField.setBounds(ageFieldBounds);
        add(ageField);
        storeComponentForAnimation(ageField, ageFieldBounds);
        yPos += yGap;

        // --- Row 3: Address ---
        addressLabel = new JLabel("Address:");
        addressLabel.setFont(FONT_LABEL_BOLD);
        Rectangle addressLabelBounds = new Rectangle(labelX, yPos, 120, fieldHeight);
        addressLabel.setBounds(addressLabelBounds);
        add(addressLabel);
        storeComponentForAnimation(addressLabel, addressLabelBounds);

        addressField = createStyledTextField();
        int addressFieldWidth = (ageFieldBounds.x + ageFieldBounds.width) - fieldStartX; // Align end with ageField
        Rectangle addressFieldBounds = new Rectangle(fieldStartX, yPos, addressFieldWidth, fieldHeight);
        addressField.setBounds(addressFieldBounds);
        add(addressField);
        storeComponentForAnimation(addressField, addressFieldBounds);
        yPos += yGap;

        // --- Row 4: Mobile and Join Date (on the same line) ---
        mobileLabel = new JLabel("Mobile No:");
        mobileLabel.setFont(FONT_LABEL_BOLD);
        Rectangle mobileLabelBounds = new Rectangle(labelX, yPos, 120, fieldHeight);
        mobileLabel.setBounds(mobileLabelBounds);
        add(mobileLabel);
        storeComponentForAnimation(mobileLabel, mobileLabelBounds);

        mobileField = createStyledTextField();
        Rectangle mobileFieldBounds = new Rectangle(fieldStartX, yPos, nameFieldWidth, fieldHeight); // Same width as name field
        mobileField.setBounds(mobileFieldBounds);
        add(mobileField);
        storeComponentForAnimation(mobileField, mobileFieldBounds);

        int joinDateLabelX = fieldStartX + nameFieldWidth + pairedElementGap;
        joinDateLabel = new JLabel("Join Date:");
        joinDateLabel.setFont(FONT_LABEL_BOLD);
        Rectangle joinDateLabelBounds = new Rectangle(joinDateLabelX, yPos, 90, fieldHeight);
        joinDateLabel.setBounds(joinDateLabelBounds);
        add(joinDateLabel);
        storeComponentForAnimation(joinDateLabel, joinDateLabelBounds);

        joinDateField = new JFormattedTextField(new SimpleDateFormat("yyyy-MM-dd"));
        joinDateField.setFont(FONT_FIELD_INPUT);
        joinDateField.setBorder(createStyledTextFieldBorder());
        joinDateField.setBackground(COLOR_BACKGROUND_MAIN);
        joinDateField.setValue(new Date()); // Default to today's date
        joinDateField.setToolTipText("Format: YYYY-MM-DD");
        Rectangle joinDateFieldBounds = new Rectangle(joinDateLabelX + joinDateLabel.getWidth() + 10, yPos, 120, fieldHeight);
        joinDateField.setBounds(joinDateFieldBounds);
        add(joinDateField);
        storeComponentForAnimation(joinDateField, joinDateFieldBounds);
        yPos += yGap + 15; // Extra gap before buttons

        // --- Buttons: Save, Reset, Update ---
        int buttonYPos = yPos;
        int buttonWidth = 150;
        int buttonHeight = 35;
        int buttonGap = 20;

        saveButton = createStyledButton("Save Trainer", COLOR_BUTTON_GREEN, COLOR_BUTTON_GREEN.brighter(), COLOR_BUTTON_GREEN.darker());
        Rectangle saveButtonBounds = new Rectangle(fieldStartX, buttonYPos, buttonWidth, buttonHeight);
        saveButton.setBounds(saveButtonBounds);
        add(saveButton);
        storeComponentForAnimation(saveButton, saveButtonBounds);

        resetButton = createStyledButton("Reset Fields", COLOR_BUTTON_ORANGE, COLOR_BUTTON_ORANGE.brighter(), COLOR_BUTTON_ORANGE.darker());
        Rectangle resetButtonBounds = new Rectangle(fieldStartX + buttonWidth + buttonGap, buttonYPos, buttonWidth, buttonHeight);
        resetButton.setBounds(resetButtonBounds);
        add(resetButton);
        storeComponentForAnimation(resetButton, resetButtonBounds);

        updateButton = createStyledButton("Update Trainer", COLOR_BUTTON_BLUE, COLOR_BUTTON_BLUE.brighter(), COLOR_BUTTON_BLUE.darker());
        updateButton.setEnabled(false); // Initially disabled
        Rectangle updateButtonBounds = new Rectangle(fieldStartX + (buttonWidth + buttonGap) * 2, buttonYPos, buttonWidth + 10, buttonHeight); // Slightly wider
        updateButton.setBounds(updateButtonBounds);
        add(updateButton);
        storeComponentForAnimation(updateButton, updateButtonBounds);
        yPos = buttonYPos + buttonHeight + 20; // Update yPos after button row

        // --- Separator ---
        JSeparator separator = new JSeparator();
        Rectangle separatorBounds = new Rectangle(30, yPos, getWidth() - 60, 10);
        separator.setBounds(separatorBounds);
        add(separator);
        storeComponentForAnimation(separator, separatorBounds);
        yPos += 25; // Gap after separator

        // --- Trainer List Title and Refresh Button ---
        JLabel listTitleLabel = new JLabel("Current Trainers List:");
        listTitleLabel.setFont(FONT_SECTION_TITLE);
        listTitleLabel.setForeground(COLOR_PRIMARY);
        Rectangle listTitleBounds = new Rectangle(30, yPos, 250, 30);
        listTitleLabel.setBounds(listTitleBounds);
        add(listTitleLabel);
        storeComponentForAnimation(listTitleLabel, listTitleBounds);

        refreshButton = createStyledButton("Refresh List", COLOR_PRIMARY, COLOR_PRIMARY.brighter(), COLOR_PRIMARY.darker());
        Rectangle refreshButtonBounds = new Rectangle(getWidth() - 30 - (buttonWidth + 20), yPos, buttonWidth + 20, 30);
        refreshButton.setBounds(refreshButtonBounds);
        add(refreshButton);
        storeComponentForAnimation(refreshButton, refreshButtonBounds);
        yPos += listTitleLabel.getHeight() + 15; // Gap before table

        // --- Trainer Table ---
        String[] columnNames = {"ID", "Name", "Age", "Address", "Join Date", "Mobile"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table cells non-editable by default
            }
        };
        trainerTable = new JTable(tableModel);
        trainerTable.setFont(FONT_GLOBAL_REGULAR);
        trainerTable.setRowHeight(28); // Comfortable row height
        trainerTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        trainerTable.setFillsViewportHeight(true); // Table uses entire height of scroll pane
        trainerTable.setGridColor(COLOR_PRIMARY.brighter());
        trainerTable.setShowVerticalLines(true);
        trainerTable.setShowHorizontalLines(true);


        JTableHeader tableHeader = trainerTable.getTableHeader();
        tableHeader.setFont(FONT_LABEL_BOLD);
        tableHeader.setBackground(COLOR_PRIMARY);
        tableHeader.setForeground(Color.WHITE);
        tableHeader.setReorderingAllowed(false); // Prevent column reordering

    //    sorter = new TableRowSorter<>(tableModel);
    //    trainerTable.setRowSorter(sorter);
        trainerTable.setRowSorter(null); 
        scrollPane = new JScrollPane(trainerTable);
        scrollPane.getViewport().setBackground(Color.WHITE); // Background for empty table area
        // Calculate bounds for the JScrollPane to fill remaining space
        Rectangle scrollPaneTargetBounds = new Rectangle(
                30, yPos,
                getWidth() - 60, // Frame width - left/right margins
                getHeight() - yPos - 30 // Remaining height - top offset - bottom margin
        );
        scrollPane.setBounds(scrollPaneTargetBounds);
        add(scrollPane);
     // storeComponentForAnimation(scrollPane, scrollPaneTargetBounds);

        setTableColumnWidths();
    }

    private JTextField createStyledTextField() {
        JTextField textField = new JTextField();
        textField.setFont(FONT_FIELD_INPUT);
        textField.setBorder(createStyledTextFieldBorder());
        textField.setBackground(COLOR_BACKGROUND_MAIN); // Match form background
        return textField;
    }

    private javax.swing.border.Border createStyledTextFieldBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, COLOR_TEXT_FIELD_BORDER), // Bottom border
                new EmptyBorder(5, 8, 5, 8) // Padding inside text field
        );
    }

    private JButton createStyledButton(String text, Color bg, Color hover, Color pressed) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(bg);
        button.setFocusPainted(false); // Remove the dotted focus border
        button.setBorder(new EmptyBorder(8, 18, 8, 18)); // Padding
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Add mouse listener for hover and pressed effects
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(hover);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(bg);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                button.setBackground(pressed);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                // Check if mouse is still over the button on release
                if (button.getBounds().contains(e.getPoint())) {
                    button.setBackground(hover);
                } else {
                    button.setBackground(bg);
                }
            }
        });
        return button;
    }

    private void addUIListeners() {
        closeButton.addActionListener(this);
        refreshButton.addActionListener(this);
        saveButton.addActionListener(this);
        resetButton.addActionListener(this);
        updateButton.addActionListener(this);
        trainerTable.addMouseListener(this);

        // Optional: Allow login with Enter key on relevant fields (e.g. last field before save)
        mobileField.addActionListener(e -> saveButton.doClick()); // Example
    }

    private void storeComponentForAnimation(Component comp, Rectangle targetBounds) {
        if (comp == null || targetBounds == null) {
            System.err.println("Attempted to store null component or bounds for animation.");
            return;
        }
        animatedComponentsList.add(comp);
        targetBoundsList.add(targetBounds);
        comp.setVisible(false); // Hide initially; animation will reveal it
    }

    private void prepareComponentsForAnimation() {
        for (int i = 0; i < animatedComponentsList.size(); i++) {
            Component comp = animatedComponentsList.get(i);
            Rectangle targetRect = targetBoundsList.get(i);

            if (comp instanceof JScrollPane || comp instanceof JSeparator) {
                // These components will animate their width from 0
                comp.setBounds(targetRect.x, targetRect.y, 0, targetRect.height);
            } else {
                // Other components slide in from the left
                comp.setBounds(targetRect.x + ANIMATION_X_OFFSET_SLIDE, targetRect.y, targetRect.width, targetRect.height);
            }
            comp.setVisible(false); // Ensure components are hidden before animation starts
        }
    }

    private void startWindowFadeInAnimation() {
        setOpacity(0f); // Start fully transparent (works best with undecorated frames)
        windowFadeInTimer = new Timer(20, e -> { // Adjust delay (20ms) for speed
            currentWindowOpacity += 0.05f; // Adjust increment (0.05f) for speed
            if (currentWindowOpacity >= 1.0f) {
                currentWindowOpacity = 1.0f;
                setOpacity(currentWindowOpacity);
                ((Timer) e.getSource()).stop();
                startFormComponentsSlideInAnimation(); // Trigger next animation after fade-in
            } else {
                setOpacity(currentWindowOpacity);
            }
        });
        windowFadeInTimer.start();
    }

    private void startFormComponentsSlideInAnimation() {
        animationProgressCounter = 0;
        componentsSlideInTimer = new Timer(15, e -> { // Timer for each animation step
            boolean allComponentsAreAtTarget = true;

            for (int i = 0; i < animatedComponentsList.size(); i++) {
                // Stagger the start of animation for each component
                if (animationProgressCounter < i * ANIMATION_STAGGER_DELAY_STEPS) {
                    allComponentsAreAtTarget = false; // Not all components have started animating yet
                    continue;
                }

                Component comp = animatedComponentsList.get(i);
                Rectangle targetRect = targetBoundsList.get(i);
                Rectangle currentBounds = comp.getBounds();

                comp.setVisible(true); // Make component visible as its animation begins

                int newAnimatedX = currentBounds.x;
                int newAnimatedY = targetRect.y; // Y position is generally fixed at target
                int newAnimatedWidth = currentBounds.width;
                int newAnimatedHeight = targetRect.height; // Height is generally fixed at target

                boolean isThisComponentDone = true;

                if (comp instanceof JScrollPane || comp instanceof JSeparator) {
                    // Animate width from 0 to target.width
                    if (newAnimatedWidth < targetRect.width) {
                        newAnimatedWidth += Math.max(1, (targetRect.width - newAnimatedWidth) / 8); // Animation speed factor
                        if (newAnimatedWidth >= targetRect.width) {
                            newAnimatedWidth = targetRect.width; // Snap to target
                        } else {
                            isThisComponentDone = false; // Still animating
                        }
                    }
                    newAnimatedX = targetRect.x; // X position remains fixed at target
                } else {
                    // Animate X position from offset to target.x (slide-in effect)
                    if (newAnimatedX < targetRect.x) {
                        newAnimatedX += Math.max(1, (targetRect.x - newAnimatedX) / 8); // Animation speed factor
                        if (newAnimatedX >= targetRect.x) {
                            newAnimatedX = targetRect.x; // Snap to target
                        } else {
                            isThisComponentDone = false; // Still animating
                        }
                    }
                    newAnimatedWidth = targetRect.width; // Width remains fixed for sliding components
                }

                comp.setBounds(newAnimatedX, newAnimatedY, newAnimatedWidth, newAnimatedHeight);

                if (!isThisComponentDone) {
                    allComponentsAreAtTarget = false; // If any component is still animating, not all are done
                }
            }

            animationProgressCounter++;

            if (allComponentsAreAtTarget) {
                ((Timer) e.getSource()).stop(); // Stop the animation timer
                // Crucial: Ensure all components are precisely at their final target bounds
                for (int i = 0; i < animatedComponentsList.size(); i++) {
                    animatedComponentsList.get(i).setBounds(targetBoundsList.get(i));
                    animatedComponentsList.get(i).setVisible(true); // Ensure all are visible
                }
                // System.out.println("Slide-in animation complete. Final ScrollPane bounds: " + scrollPane.getBounds());
            }
        });
        componentsSlideInTimer.start();
    }

    private void setTableColumnWidths() {
        trainerTable.getColumnModel().getColumn(0).setPreferredWidth(60);    // ID
        trainerTable.getColumnModel().getColumn(1).setPreferredWidth(200);   // Name
        trainerTable.getColumnModel().getColumn(2).setPreferredWidth(70);    // Age
        trainerTable.getColumnModel().getColumn(3).setPreferredWidth(280);   // Address
        trainerTable.getColumnModel().getColumn(4).setPreferredWidth(120);   // Join Date
        trainerTable.getColumnModel().getColumn(5).setPreferredWidth(130);   // Mobile
    }

    private void loadTrainerDataFromDB() {
        tableModel.setRowCount(0); // Clear existing data from the table model
        String query = "SELECT ID, name, age, address, joinDate, mobile FROM trainer ORDER BY ID";

        try (Connection con = ConnectionProvider.getCon();
             Statement st = (con != null) ? con.createStatement() : null;
             ResultSet rs = (st != null) ? st.executeQuery(query) : null) {

            if (con == null) {
                JOptionPane.showMessageDialog(this, "Database connection failed. Please check configuration.", "DB Connection Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (st == null || rs == null) { // Should not happen if con is not null, but good practice
                 JOptionPane.showMessageDialog(this, "Failed to create statement or execute query.", "DB Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("ID"));
                row.add(rs.getString("name"));
                int ageValue = rs.getInt("age");
                row.add(rs.wasNull() ? "" : ageValue); // Handle potential null age from DB
                row.add(rs.getString("address"));
                row.add(rs.getDate("joinDate")); // java.sql.Date
                row.add(rs.getString("mobile"));
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading trainer data: " + e.getMessage(), "Database Query Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace(); // Log detailed error to console
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == closeButton) {
            // Optional: Implement a fade-out animation before disposing
            setVisible(false);
            dispose(); // Release resources
        } else if (source == refreshButton) {
            loadTrainerDataFromDB();
            resetInputFieldsAndState();
        } else if (source == saveButton) {
            saveNewTrainer();
        } else if (source == resetButton) {
            resetInputFieldsAndState();
        } else if (source == updateButton) {
            updateSelectedTrainer();
        }
    }

    private void resetInputFieldsAndState() {
        idField.setText("");
        nameField.setText("");
        ageField.setText("");
        addressField.setText("");
        mobileField.setText("");
        joinDateField.setValue(new Date()); // Reset date to today

        selectedTrainerId = -1; // No trainer selected
        updateButton.setEnabled(false); // Disable update until a row is selected
        saveButton.setEnabled(true);    // Enable save for new entries
        idField.setEditable(false);     // ID field usually not editable
        nameField.requestFocusInWindow(); // Set focus to the first editable field
        trainerTable.clearSelection(); // Clear any table selection
    }

    private boolean validateTrainerInputs(String name, String ageStr, String address, String mobile, Date joinDateValue) {
        if (name.isEmpty() || address.isEmpty() || mobile.isEmpty() || joinDateValue == null) {
            JOptionPane.showMessageDialog(this, "Name, Address, Mobile, and Join Date are required fields.", "Input Required", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (!ageStr.isEmpty()) {
            try {
                int ageNum = Integer.parseInt(ageStr);
                if (ageNum <= 16 || ageNum > 100) { // Basic age validation
                    JOptionPane.showMessageDialog(this, "Please enter a valid age (e.g., 17-100).", "Invalid Age", JOptionPane.WARNING_MESSAGE);
                    return false;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid format for Age. Please enter a number.", "Input Format Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        // Basic mobile number validation (e.g., 10-15 digits)
        if (!mobile.matches("\\d{10,15}")) {
            JOptionPane.showMessageDialog(this, "Invalid Mobile Number. Please enter 10 to 15 digits.", "Invalid Mobile", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void saveNewTrainer() {
        String name = nameField.getText().trim();
        String ageStr = ageField.getText().trim();
        String address = addressField.getText().trim();
        String mobile = mobileField.getText().trim();
        Date joinDateUtil = (Date) joinDateField.getValue();

        if (!validateTrainerInputs(name, ageStr, address, mobile, joinDateUtil)) {
            return; // Validation failed
        }

        Integer age = ageStr.isEmpty() ? null : Integer.parseInt(ageStr);
        java.sql.Date joinDateSql = new java.sql.Date(joinDateUtil.getTime());

        String query = "INSERT INTO trainer (name, age, address, joinDate, mobile) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = (con != null) ? con.prepareStatement(query) : null) {

            if (con == null || ps == null) {
                 JOptionPane.showMessageDialog(this, "Database connection error. Cannot save trainer.", "DB Connection Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            ps.setString(1, name);
            if (age == null) ps.setNull(2, Types.INTEGER);
            else ps.setInt(2, age);
            ps.setString(3, address);
            ps.setDate(4, joinDateSql);
            ps.setString(5, mobile);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "New trainer added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                resetInputFieldsAndState();
                loadTrainerDataFromDB(); // Refresh table
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add new trainer. No rows affected.", "Save Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            handleDatabaseException(e, "saving new trainer");
        }
    }

    private void updateSelectedTrainer() {
        if (selectedTrainerId == -1) {
            JOptionPane.showMessageDialog(this, "No trainer selected. Please select a trainer from the list to update.", "Update Information", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        String name = nameField.getText().trim();
        String ageStr = ageField.getText().trim();
        String address = addressField.getText().trim();
        String mobile = mobileField.getText().trim();
        Date joinDateUtil = (Date) joinDateField.getValue();

        if (!validateTrainerInputs(name, ageStr, address, mobile, joinDateUtil)) {
            return; // Validation failed
        }

        Integer age = ageStr.isEmpty() ? null : Integer.parseInt(ageStr);
        java.sql.Date joinDateSql = new java.sql.Date(joinDateUtil.getTime());

        String query = "UPDATE trainer SET name=?, age=?, address=?, joinDate=?, mobile=? WHERE ID=?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = (con != null) ? con.prepareStatement(query) : null) {

            if (con == null || ps == null) {
                 JOptionPane.showMessageDialog(this, "Database connection error. Cannot update trainer.", "DB Connection Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            ps.setString(1, name);
            if (age == null) ps.setNull(2, Types.INTEGER);
            else ps.setInt(2, age);
            ps.setString(3, address);
            ps.setDate(4, joinDateSql);
            ps.setString(5, mobile);
            ps.setInt(6, selectedTrainerId); // WHERE clause

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Trainer information updated successfully!", "Update Success", JOptionPane.INFORMATION_MESSAGE);
                resetInputFieldsAndState();
                loadTrainerDataFromDB(); // Refresh table
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update trainer. Record not found or data unchanged.", "Update Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            handleDatabaseException(e, "updating trainer information");
        }
    }
    
    private void handleDatabaseException(SQLException e, String actionContext) {
        String errorMessage = "Database error occurred while " + actionContext + ".";
        // Check for specific SQL error codes, like duplicate entry (MySQL error code 1062)
        if (e.getErrorCode() == 1062) { 
            errorMessage = "Error: A trainer with this mobile number or other unique identifier may already exist.";
        } else {
            errorMessage += "\nDetails: " + e.getMessage();
        }
        JOptionPane.showMessageDialog(this, errorMessage, "Database Operation Failed", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace(); // Log detailed error to console for debugging
    }


    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource() == trainerTable) {
            int selectedViewRow = trainerTable.getSelectedRow();
            if (selectedViewRow != -1) { // Check if a row is actually selected
                int modelRowIndex = trainerTable.convertRowIndexToModel(selectedViewRow); // Convert view index to model index if sorting/filtering

                selectedTrainerId = (int) tableModel.getValueAt(modelRowIndex, 0); // ID
                idField.setText(String.valueOf(selectedTrainerId));
                nameField.setText((String) tableModel.getValueAt(modelRowIndex, 1)); // Name

                Object ageObject = tableModel.getValueAt(modelRowIndex, 2); // Age
                ageField.setText(ageObject == null ? "" : String.valueOf(ageObject));

                addressField.setText((String) tableModel.getValueAt(modelRowIndex, 3)); // Address

                Object dateObject = tableModel.getValueAt(modelRowIndex, 4); // Join Date (java.sql.Date)
                if (dateObject instanceof java.sql.Date) {
                    // Convert java.sql.Date to java.util.Date for JFormattedTextField
                    joinDateField.setValue(new Date(((java.sql.Date) dateObject).getTime()));
                } else if (dateObject instanceof String) { // Fallback if date is stored as string in model (should not happen with current load)
                    try {
                        joinDateField.setValue(new SimpleDateFormat("yyyy-MM-dd").parse((String) dateObject));
                    } catch (ParseException ex) {
                        joinDateField.setValue(new Date()); // Default on error
                        System.err.println("Error parsing date string from table model: " + dateObject);
                    }
                } else {
                     joinDateField.setValue(new Date()); // Default if type is unexpected
                }

                mobileField.setText((String) tableModel.getValueAt(modelRowIndex, 5)); // Mobile

                // Update UI state for editing
                updateButton.setEnabled(true);  // Enable update button
                saveButton.setEnabled(false);   // Disable save button to prevent accidental new entry
                idField.setEditable(false);     // ID is not editable
            }
        }
    }

    // Other mouse listener methods (can be left empty if not used)
    @Override public void mousePressed(MouseEvent e) {}
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}

    /**
     * Main method for testing this frame independently.
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        // Ensure Swing components are created and managed on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> new trainer());
    }
}