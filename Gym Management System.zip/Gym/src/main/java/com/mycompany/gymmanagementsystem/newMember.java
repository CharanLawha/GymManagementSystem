/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.gymmanagementsystem;
/*auther charan */

import com.mysql.cj.xdevapi.Result;
import javax.swing.*;
import database.ConnectionProvider;
import java.awt.Color;
import java.sql.*;
import java.util.regex.Pattern;





// Or your chosen package name

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date; // Use java.util.Date for current date

/**
 * Frame for adding a new member to the Gym Management System.
 */
public class newMember extends JFrame implements ActionListener, FocusListener {

    // --- UI Components ---
    private JLabel titleLabel, idLabel;
    private JTextField idField; // Input field for Member ID
    private JLabel firstNameLabel, lastNameLabel, genderLabel, phoneLabel, emailLabel, addressLabel;
    private JLabel typeLabel, regDateLabel, trainerLabel;
    private JTextField firstNameField, lastNameField, phoneField, emailField, addressField;
    private JComboBox<String> genderCombo, typeCombo, trainerCombo;
    private JTextField regDateField;
    private JButton saveButton, resetButton, closeButton;

    /**
     * Constructor: Sets up the new member frame.
     */
    public newMember() {
        // --- Frame Setup ---
        setTitle("Add New Member");
        setSize(800, 600); // Adjusted size
        setLocationRelativeTo(null); // Center
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this window
        setUndecorated(true); // Optional: remove decorations
        setLayout(null);
        getContentPane().setBackground(new Color(230, 255, 230)); // Light green background

        // --- Title and Close Button ---
        titleLabel = new JLabel("NEW MEMBER REGISTRATION");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setForeground(new Color(0, 102, 51)); // Dark green
        titleLabel.setBounds(180, 20, 500, 35);
        add(titleLabel);

        closeButton = new JButton("X");
        closeButton.setFont(new Font("Arial", Font.BOLD, 16));
        closeButton.setForeground(Color.WHITE);
        closeButton.setBackground(Color.RED);
        closeButton.setBounds(740, 10, 50, 30);
        closeButton.addActionListener(this);
        add(closeButton);

        // --- Member ID (Manual Input) ---
        idLabel = new JLabel("Member ID:");
        idLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        idLabel.setBounds(50, 80, 100, 25);
        add(idLabel);
        idField = new JTextField(); // Input field for Member ID
        idField.setFont(new Font("Tahoma", Font.PLAIN, 14));
        idField.setBounds(180, 80, 100, 25);
        idField.addFocusListener(this); // Listen for focus loss to check ID
        add(idField);


        // --- Input Fields ---
        int labelX = 50;
        int fieldX = 180;
        int labelWidth = 120;
        int fieldWidth = 250;
        int yPos = 120;
        int yGap = 40;
        Font labelFont = new Font("Tahoma", Font.BOLD, 14);
        Font fieldFont = new Font("Tahoma", Font.PLAIN, 14);

        firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setFont(labelFont);
        firstNameLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(firstNameLabel);
        firstNameField = new JTextField();
        firstNameField.setFont(fieldFont);
        firstNameField.setBounds(fieldX, yPos, fieldWidth, 25);
        add(firstNameField);
        yPos += yGap;

        lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setFont(labelFont);
        lastNameLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(lastNameLabel);
        lastNameField = new JTextField();
        lastNameField.setFont(fieldFont);
        lastNameField.setBounds(fieldX, yPos, fieldWidth, 25);
        add(lastNameField);
        yPos += yGap;

        genderLabel = new JLabel("Gender:");
        genderLabel.setFont(labelFont);
        genderLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(genderLabel);
        genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderCombo.setFont(fieldFont);
        genderCombo.setBounds(fieldX, yPos, fieldWidth, 25);
        genderCombo.setBackground(Color.WHITE);
        add(genderCombo);
        yPos += yGap;

        phoneLabel = new JLabel("Phone Number:");
        phoneLabel.setFont(labelFont);
        phoneLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(phoneLabel);
        phoneField = new JTextField();
        phoneField.setFont(fieldFont);
        phoneField.setBounds(fieldX, yPos, fieldWidth, 25);
        add(phoneField);
        yPos += yGap;

        emailLabel = new JLabel("Email:");
        emailLabel.setFont(labelFont);
        emailLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(emailLabel);
        emailField = new JTextField();
        emailField.setFont(fieldFont);
        emailField.setBounds(fieldX, yPos, fieldWidth, 25);
        add(emailField);
        yPos += yGap;

        addressLabel = new JLabel("Address:");
        addressLabel.setFont(labelFont);
        addressLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(addressLabel);
        addressField = new JTextField();
        addressField.setFont(fieldFont);
        addressField.setBounds(fieldX, yPos, fieldWidth + 150, 25); // Wider address field
        add(addressField);
        yPos += yGap;

        // --- Right Side Fields ---
        labelX = 450;
        fieldX = 580; // Adjusted field X
        fieldWidth = 180; // Slightly narrower for right side
        yPos = 120; // Reset Y for the second column

        typeLabel = new JLabel("Member Type:");
        typeLabel.setFont(labelFont);
        typeLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(typeLabel);
        typeCombo = new JComboBox<>(new String[]{"Basic", "Plus", "Premium"});
        typeCombo.setFont(fieldFont);
        typeCombo.setBounds(fieldX, yPos, fieldWidth, 25);
        typeCombo.setBackground(Color.WHITE);
        typeCombo.addActionListener(this); // Listen for type changes
        add(typeCombo);
        yPos += yGap;

        regDateLabel = new JLabel("Register Date:");
        regDateLabel.setFont(labelFont);
        regDateLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(regDateLabel);
        regDateField = new JTextField();
        regDateField.setFont(fieldFont);
        regDateField.setBounds(fieldX, yPos, fieldWidth, 25);
        regDateField.setEditable(false); // Set by system
        regDateField.setText(new SimpleDateFormat("yyyy-MM-dd").format(new Date())); // Set current date
        add(regDateField);
        yPos += yGap;

        trainerLabel = new JLabel("Assign Trainer:");
        trainerLabel.setFont(labelFont);
        trainerLabel.setBounds(labelX, yPos, labelWidth, 25);
        add(trainerLabel);
        trainerCombo = new JComboBox<>();
        trainerCombo.setFont(fieldFont);
        trainerCombo.setBounds(fieldX, yPos, fieldWidth, 25);
        trainerCombo.setBackground(Color.WHITE);
        loadTrainers(); // Load trainers into the combo box
        add(trainerCombo);
        yPos += yGap + 30; // Adjusted gap


        // --- Buttons ---
        saveButton = new JButton("Save");
        saveButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        saveButton.setBackground(new Color(0, 153, 51));
        saveButton.setForeground(Color.WHITE);
        saveButton.setBounds(250, 500, 100, 35); // Adjusted position
        saveButton.addActionListener(this);
        add(saveButton);

        resetButton = new JButton("Reset");
        resetButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        resetButton.setBackground(new Color(255, 153, 0));
        resetButton.setForeground(Color.WHITE);
        resetButton.setBounds(400, 500, 100, 35); // Adjusted position
        resetButton.addActionListener(this);
        add(resetButton);

        // Make frame visible
        setVisible(true);

        // Set initial amount based on default member type (optional, if you want a default)
        // updateAmountBasedOnType();
    }

    /**
     * Checks if the entered Member ID already exists in the database.
     */
    private boolean isMemberIdExists(String memberId) {
        String query = "SELECT ID FROM member WHERE ID = ?";
        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, memberId);
            ResultSet rs = pst.executeQuery();
            return rs.next(); // Returns true if ID exists
        } catch (SQLException e) {
            System.err.println("Error checking Member ID: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Database error checking Member ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return false; // Assume ID doesn't exist on error
        }
    }

    /**
     * Loads trainer names and IDs into the trainer combo box.
     */
    private void loadTrainers() {
        trainerCombo.addItem("None"); // Option for no trainer
        String query = "SELECT ID, name FROM trainer ORDER BY name";
        try (Connection con = ConnectionProvider.getCon();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(query)) {

            while (rs.next()) {
                // Store both ID and Name, display Name
                trainerCombo.addItem(rs.getInt("ID") + ": " + rs.getString("name"));
            }
        } catch (SQLException e) {
            System.err.println("Error loading trainers: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Could not load trainer list.", "Database Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            System.err.println("Unexpected error loading trainers: " + e.getMessage());
        }
    }


    /**
     * Handles button clicks and combo box selections.
     * @param e The ActionEvent object.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == saveButton) {
            saveMember();
        } else if (e.getSource() == resetButton) {
            resetForm();
        } else if (e.getSource() == closeButton) {
            setVisible(false); // Just close this window
            dispose(); // Release resources
        }
    }

    /**
     * Resets all input fields on the form.
     */
    private void resetForm() {
        idField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        phoneField.setText("");
        emailField.setText("");
        addressField.setText("");
        genderCombo.setSelectedIndex(0);
        typeCombo.setSelectedIndex(0);
        trainerCombo.setSelectedIndex(0); // Set back to "None"
        regDateField.setText(new SimpleDateFormat("yyyy-MM-dd").format(new Date())); // Reset reg date
    }

    /**
     * Saves the new member data to the database.
     */
    private void saveMember() {
        String memberId = idField.getText().trim();

        // --- Check if Member ID is entered ---
        if (memberId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Member ID.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // --- Check if Member ID already exists ---
        if (isMemberIdExists(memberId)) {
            JOptionPane.showMessageDialog(this, "Member ID '" + memberId + "' already exists. Please enter a unique ID.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // --- Data Validation (Basic Example) ---
        if (firstNameField.getText().trim().isEmpty() || lastNameField.getText().trim().isEmpty() ||
            phoneField.getText().trim().isEmpty() || emailField.getText().trim().isEmpty() ||
            addressField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields (First Name, Last Name, Phone, Email, Address).", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // --- Get Data from Fields ---
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String gender = (String) genderCombo.getSelectedItem();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();
        String address = addressField.getText().trim();
        String memberType = (String) typeCombo.getSelectedItem();
        String regDateStr = regDateField.getText(); // Already in YYYY-MM-dd

        // --- Determine Amount Based on Member Type ---
        double amountPay = 0.0;
        switch (memberType) {
            case "Basic":
                amountPay = 1999;
                break;
            case "Plus":
                amountPay = 2999;
                break;
            case "Premium":
                amountPay = 4999;
                break;
            default:
                JOptionPane.showMessageDialog(this, "Invalid Member Type selected.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
        }

        // --- Handle Trainer Selection ---
        Integer trainerId = null; // Use Integer to allow null
        String selectedTrainer = (String) trainerCombo.getSelectedItem();
        if (selectedTrainer != null && !selectedTrainer.equals("None")) {
            try {
                trainerId = Integer.parseInt(selectedTrainer.split(":")[0]); // Extract ID
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException ex) {
                System.err.println("Error parsing trainer ID from: " + selectedTrainer);
                // Handle error appropriately, maybe default to null or show message
            }
        }

        // --- Handle Dates ---
        java.sql.Date regDateSql = null;
        try {
            // Registration date should always be valid as it's system-set
             regDateSql = java.sql.Date.valueOf(regDateStr);
        } catch (IllegalArgumentException ex) {
             JOptionPane.showMessageDialog(this, "Invalid date format encountered.", "Input Error", JOptionPane.WARNING_MESSAGE);
             return;
        }


        // --- Database Insertion ---
        Connection con = null;
        PreparedStatement psMember = null;

        try {
            con = ConnectionProvider.getCon();
            if (con == null) {
                 JOptionPane.showMessageDialog(this, "Database connection failed.", "Error", JOptionPane.ERROR_MESSAGE);
                 return;
            }

            // Insert into member table
            String memberQuery = "INSERT INTO member (ID, firstName, lastName, gender, phoneNum, email, address, amountPay, memberType, dateRegister, trainerID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            psMember = con.prepareStatement(memberQuery);

            psMember.setString(1, memberId);
            psMember.setString(2, firstName);
            psMember.setString(3, lastName);
            psMember.setString(4, gender);
            psMember.setString(5, phone);
            psMember.setString(6, email);
            psMember.setString(7, address);
            psMember.setDouble(8, amountPay); // Set the automatically determined amount
            psMember.setString(9, memberType);
            psMember.setDate(10, regDateSql);
            if (trainerId == null) {
                psMember.setNull(11, Types.INTEGER);
            } else {
                psMember.setInt(11, trainerId);
            }

            int rowsAffected = psMember.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Member saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                resetForm(); // Clear form for next entry
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save member.", "Error",
                		JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error saving member: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace(); // Log detailed error
        } finally {
            // Close resources in finally block
             try { if (psMember != null) psMember.close(); } catch (SQLException e) { e.printStackTrace(); }
             try { if (con != null) con.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    @Override
    public void focusGained(FocusEvent e) {
        // Not needed for now
    }

    @Override
    public void focusLost(FocusEvent e) {
        if (e.getSource() == idField) {
            String memberId = idField.getText().trim();
            if (!memberId.isEmpty() && isMemberIdExists(memberId)) {
                JOptionPane.showMessageDialog(this, "Member ID '" + memberId + "' already exists. Please enter a unique ID.", "Error", JOptionPane.ERROR_MESSAGE);
                idField.requestFocusInWindow(); // Set focus back to the ID field
            }
        }
    }


    /**
     * Main method (for testing purposes).
     * @param args Command line arguments (not used).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new newMember());
    }
}