
DROP DATABASE IF EXISTS hms;
CREATE DATABASE hms;
USE hms;



DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `phoneNum` varchar(15) NOT NULL, 
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `amountPay` decimal(6,2) DEFAULT NULL, 
  `memberType` varchar(255) DEFAULT NULL,
  `dateRegister` date NOT NULL,
  `trainer` varchar(255) DEFAULT NULL,
  `payDate` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ;

LOCK TABLES `member` WRITE;
INSERT INTO `member` VALUES 
(1, 'Tai', 'Quach', 'Male', '8352342155', 'taiquach@gmail.com', '123 Kenwell Dr Houston TX77083', 19.99, 'Plus', '2022-04-22', 'trainer 1', '2022-04-22'),
(2, 'Kevin', 'Ly', 'Male', '8432158423', 'kevinly@gmail.com', '6162 Sunmount Pines Dr', 19.99, 'Plus', '2022-04-22', 'trainer 2', '2022-04-23'),
(3, 'Hung', 'Nguyen', 'Male', '2342153125', 'hnguyen@yahoo.com', '123 Queensland Way Houston TX77083', 24.99, 'Premium', '2022-04-21', NULL, NULL),
(4, 'Vy', 'Trinh', 'Female', '5218543251', 'bnguyen@gmail.com', '3223 Walwick Dr Houston TX77377', 9.99, 'Basic', '2022-04-23', 'none', NULL);
UNLOCK TABLES;


DROP TABLE IF EXISTS `payment`;
CREATE TABLE `payment` (
  `ID` int NOT NULL,
  `memberName` varchar(255) DEFAULT NULL,
  `memberType` varchar(255) DEFAULT NULL,
  `amountPay` decimal(6,2) DEFAULT NULL,
  `paymentDate` date DEFAULT NULL,
  `dueDate` date DEFAULT NULL,
  `dayRemaining` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `unique_payment` (`ID`,`memberName`,`memberType`,`amountPay`,`paymentDate`,`dueDate`)
) ;


LOCK TABLES `payment` WRITE;
INSERT INTO `payment` VALUES 
(1, 'Tai Quach', 'Plus', 19.99, '2022-04-22', '2022-05-22', '29 Days', 'Paid'),
(2, 'Kevin Ly', 'Plus', 19.99, '2022-04-23', '2022-05-23', '30 Days', 'Paid'),
(3, 'Hung Nguyen', 'Premium', 24.99, NULL, NULL, '0 Days', 'Not Paid'),
(4, 'Vy Trinh', 'Basic', 9.99, NULL, NULL, '0 Days', 'Not Paid');
UNLOCK TABLES;


DROP TABLE IF EXISTS `trainer`;
CREATE TABLE `trainer` (
  `ID` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `age` int DEFAULT NULL, -- Changed to int for logical data typing
  `address` varchar(255) DEFAULT NULL,
  `joinDate` date DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ;


LOCK TABLES `trainer` WRITE;
INSERT INTO `trainer` VALUES 
(1, 'trainer 1', 25, '123 xxxx Houston TX 77055', '2022-04-15', '5138541254'),
(2, 'trainer 2', 30, '6161 aaaa Houston TX 77088', '2022-04-21', '5419651547');
UNLOCK TABLES;

